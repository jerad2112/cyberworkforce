# CWF Compliance Portal — ALM Build Package
## DoD8140CWFCompliance v3.0 | GitHub PowerApp Builder Ready

---

## Package Contents

```
CWF_ALM_Build/
├── .github/
│   └── workflows/
│       ├── pr-validation.yml          # PR validation (structure, config, solution checker)
│       ├── deploy-to-dev.yml          # Dev deployment (auto on develop branch push)
│       └── deploy-to-prod.yml         # Prod deployment (manual with approval gate)
├── config/
│   ├── dev-environment.json           # Development — 25 env vars, 5 connections
│   ├── test-environment.json          # Test/UAT — 25 env vars, 5 connections
│   └── prod-environment.json          # Production — 25 env vars, 5 connections
├── connection-references/
│   └── connection-references.json     # 6 connection definitions (5 required, 1 optional)
├── environment-variables/
│   └── environment-variables.json     # 25 variable definitions (22 required, 3 optional)
├── scripts/
│   ├── CWF-DATAVERSE-AUTH.ps1         # Shared auth helper (dot-source in other scripts)
│   ├── CWF-CREATE-ENVIRONMENT-VARIABLES.ps1  # Create/validate env vars via Web API
│   ├── CWF-EXPORT-SOLUTION.ps1        # Export & unpack solution via pac CLI
│   ├── CWF-SETUP-SERVICE-PRINCIPAL.ps1 # Azure AD app reg + service principal setup
│   └── CWF-VALIDATE-DEPLOYMENT.ps1    # Post-deployment validation (7 check categories)
├── solutions/
│   └── DoD8140CWFCompliance/          # Solution export target (populated after export)
│       └── README.md
├── .gitignore
└── README.md                          # This file
```

---

## Quick Start (4 Steps)

### Step 1: Export Your Existing Solution

```powershell
.\scripts\CWF-EXPORT-SOLUTION.ps1 `
  -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com" `
  -SolutionName "DoD8140CWFCompliance"
```

This exports and unpacks the solution into `solutions/DoD8140CWFCompliance/unpacked/`.

### Step 2: Create Environment Variables in Dataverse

```powershell
# Create all 25 environment variables
.\scripts\CWF-CREATE-ENVIRONMENT-VARIABLES.ps1 `
  -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"

# Validate they exist
.\scripts\CWF-CREATE-ENVIRONMENT-VARIABLES.ps1 `
  -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com" `
  -ValidateOnly
```

### Step 3: Set Up Service Principal for CI/CD

```powershell
.\scripts\CWF-SETUP-SERVICE-PRINCIPAL.ps1 `
  -EnvironmentName "DEV" `
  -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"
```

Then add the outputted secrets to your GitHub repository:  
**Settings > Secrets and variables > Actions**

| Secret Name | Description |
|---|---|
| `POWERPLATFORM_APPID` | Azure AD App (Client) ID |
| `POWERPLATFORM_CLIENTSECRET` | Client secret |
| `POWERPLATFORM_TENANTID` | Azure AD Tenant ID |
| `DEV_ENVIRONMENT_URL` | Dev Dataverse URL |
| `TEST_ENVIRONMENT_URL` | Test Dataverse URL |
| `PROD_ENVIRONMENT_URL` | Prod Dataverse URL |
| `SLACK_WEBHOOK_URL` | *(Optional)* Slack notifications |

### Step 4: Push to GitHub and Test

```bash
git init
git add .
git commit -m "Initial CWF ALM setup"
git remote add origin <your-repo-url>
git push -u origin main
git checkout -b develop
git push -u origin develop
```

Create a PR from `develop` to `main` to trigger the validation pipeline.

---

## GitHub Actions Pipelines

### PR Validation (`pr-validation.yml`)
**Triggers:** Pull requests to `main` or `develop`  
**Validates:** Solution structure, JSON configs, env var cross-references, connection refs, Solution Checker

### Deploy to Dev (`deploy-to-dev.yml`)
**Triggers:** Push to `develop` branch or manual dispatch  
**Actions:** Pack solution → Import to dev → Update env vars via Web API → Activate flows → Smoke test

### Deploy to Prod (`deploy-to-prod.yml`)
**Triggers:** Manual dispatch only (requires release tag + "DEPLOY" confirmation)  
**Actions:** Pre-checks → Backup current → Import (with approval gate) → Update env vars → Activate flows → Validate

---

## GitHub Environment Setup

Configure environment protection rules:

1. **Settings > Environments > Production**
2. Add required reviewers (cwf-admin, issm-lead)
3. Enable "Wait timer" if desired (e.g., 15 minutes)

---

## Cloud Environment Notes

All configurations target **GCC High**:
- Dataverse URLs: `.crm.dynamics.com` (your org: orge0291f5f)
- Graph API: `graph.microsoft.com`
- OAuth token endpoint: `login.microsoftonline.com`
- Power Platform Actions may require `cloud: UsGov` parameter depending on version

---

## Validation

Run post-deployment validation at any time:

```powershell
.\scripts\CWF-VALIDATE-DEPLOYMENT.ps1 `
  -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com" `
  -EnvironmentName "DEV" `
  -Detailed
```

Checks: Solution installed, 25 env vars, 5+ connection refs, flow status, 14 Dataverse tables, 8 security roles, WhoAmI connectivity.

---

## Dataverse Web API Pattern

All scripts and workflows use the **Dataverse Web API** (not fictional pac CLI commands).  
Common patterns:

```powershell
# Authenticate
$tokenBody = @{ grant_type="client_credentials"; client_id=$AppId; client_secret=$Secret; scope="$EnvUrl/.default" }
$token = (Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.us/$TenantId/oauth2/v2.0/token" -Body $tokenBody -ContentType "application/x-www-form-urlencoded").access_token

# Query
$result = Invoke-RestMethod -Uri "$EnvUrl/api/data/v9.2/environmentvariabledefinitions" -Headers @{ Authorization="Bearer $token" }

# Update
Invoke-RestMethod -Method PATCH -Uri "$EnvUrl/api/data/v9.2/environmentvariablevalues($id)" -Headers $headers -Body ($body | ConvertTo-Json)
```

---

## Version History

| Version | Date | Changes |
|---|---|---|
| 3.0.1 | 2026-03-16 | Fixed all pac CLI commands to use Dataverse Web API; added test config; added missing scripts; updated Actions to v4; fixed env var types |
| 3.0.0 | 2026-03-16 | Initial ALM scaffolding package |
