# CWF-CREATE-CONNECTION-REFERENCES.ps1
# Creates 5 required connection references in the CWF solution
# Usage: .\CWF-CREATE-CONNECTION-REFERENCES.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"
#
# Connection references are solution-aware components that decouple flows from
# specific connections, enabling environment promotion (dev -> test -> prod).

param(
    [Parameter(Mandatory=$true)]
    [string]$EnvironmentUrl,
    [Parameter(Mandatory=$false)]
    [string]$AccessToken,
    [Parameter(Mandatory=$false)]
    [switch]$ValidateOnly
)

#Requires -Version 5.1
$ErrorActionPreference = "Stop"

# AUTH
function Get-Token {
    param([string]$EnvUrl)
    if ($AccessToken) { return $AccessToken }
    $cid = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $res = "$($EnvUrl.TrimEnd('/'))/"
    Write-Host "  Requesting device code..." -ForegroundColor Yellow
    $dcr = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/common/oauth2/devicecode" `
        -Body @{ client_id = $cid; resource = $res } -ContentType "application/x-www-form-urlencoded"
    Write-Host "  Go to: $($dcr.verification_url)" -ForegroundColor Yellow
    Write-Host "  Code:  $($dcr.user_code)" -ForegroundColor Green
    Write-Host "  Waiting..." -ForegroundColor Gray
    $tb = @{ grant_type = "urn:ietf:params:oauth:grant-type:device_code"; client_id = $cid; code = $dcr.device_code }
    $iv = [Math]::Max([int]$dcr.interval, 5)
    $dl = (Get-Date).AddSeconds([int]$dcr.expires_in)
    while ((Get-Date) -lt $dl) {
        Start-Sleep -Seconds $iv
        try {
            $tr = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/common/oauth2/token" -Body $tb -ContentType "application/x-www-form-urlencoded"
            Write-Host "  Authenticated!" -ForegroundColor Green
            return $tr.access_token
        } catch {
            $e = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($e.error -eq "authorization_pending") { continue }
            elseif ($e.error -eq "slow_down") { $iv += 5; continue }
            else { throw "Auth failed: $($e.error_description)" }
        }
    }
    throw "Timed out."
}

function Invoke-DV {
    param([string]$Method = "GET", [string]$Path, [object]$Body)
    $uri = "$script:apiBase/$Path"
    $p = @{ Method = $Method; Uri = $uri; Headers = $script:headers }
    if ($Body) { $p.Body = ($Body | ConvertTo-Json -Depth 20); $p.ContentType = "application/json; charset=utf-8" }
    return Invoke-RestMethod @p
}

# ============================================================
# Connection Reference Definitions
# connectorid values are the standard Power Platform connector IDs
# ============================================================
$connectionRefs = @(
    @{
        SchemaName       = "cwf_conn_Dataverse"
        DisplayName      = "CWF Dataverse Connection"
        Description      = "Primary connection to CWF Dataverse environment for all table operations"
        ConnectorId      = "/providers/Microsoft.PowerApps/apis/shared_commondataserviceforapps"
        Category         = "Core"
        UsedByFlows      = "All 11 flows"
    },
    @{
        SchemaName       = "cwf_conn_Outlook"
        DisplayName      = "CWF Office 365 Outlook"
        Description      = "Email notifications for training reminders, SAAR approvals, compliance alerts"
        ConnectorId      = "/providers/Microsoft.PowerApps/apis/shared_office365"
        Category         = "Integration"
        UsedByFlows      = "001, 003, 005, 011"
    },
    @{
        SchemaName       = "cwf_conn_Approvals"
        DisplayName      = "CWF Approvals"
        Description      = "Multi-stage approval workflows for SAAR (DD 2875) and Privileged Access requests"
        ConnectorId      = "/providers/Microsoft.PowerApps/apis/shared_approvals"
        Category         = "Workflow"
        UsedByFlows      = "003, 005"
    },
    @{
        SchemaName       = "cwf_conn_SharePoint"
        DisplayName      = "CWF SharePoint Online"
        Description      = "Document storage for certificates, SAARs, appointment orders"
        ConnectorId      = "/providers/Microsoft.PowerApps/apis/shared_sharepointonline"
        Category         = "Integration"
        UsedByFlows      = "003, 005, 006"
    },
    @{
        SchemaName       = "cwf_conn_BlobStorage"
        DisplayName      = "CWF Azure Blob Storage"
        Description      = "Army Vantage HR data sync (inbound) and compliance data export (outbound)"
        ConnectorId      = "/providers/Microsoft.PowerApps/apis/shared_azureblob"
        Category         = "Integration"
        UsedByFlows      = "007, 008"
    }
)

# ============================================================
# MAIN
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Connection Reference Builder" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $EnvironmentUrl" -ForegroundColor White
Write-Host "Mode: $(if ($ValidateOnly) { 'VALIDATE ONLY' } else { 'CREATE' })" -ForegroundColor Yellow
Write-Host "Connection References: $($connectionRefs.Count)" -ForegroundColor White
Write-Host ""

$script:apiBase = "$($EnvironmentUrl.TrimEnd('/'))/api/data/v9.2"
$token = Get-Token -EnvUrl $EnvironmentUrl
$script:headers = @{
    "Authorization" = "Bearer $token"
    "OData-MaxVersion" = "4.0"; "OData-Version" = "4.0"
    "Accept" = "application/json"
}

# Check existing connection references
Write-Host "Checking existing connection references..." -ForegroundColor Yellow
$existingRefs = @{}
try {
    $crResult = Invoke-DV -Path "connectionreferences?`$select=connectionreferencelogicalname,connectionreferencedisplayname,connectorid"
    foreach ($cr in $crResult.value) {
        $existingRefs[$cr.connectionreferencelogicalname] = $cr
    }
    Write-Host "  Found $($existingRefs.Count) existing connection references" -ForegroundColor Gray
}
catch {
    Write-Host "  Warning: Could not query existing refs: $_" -ForegroundColor Yellow
}

$created = 0
$skipped = 0
$errors = 0

foreach ($ref in $connectionRefs) {
    $exists = $existingRefs.ContainsKey($ref.SchemaName)

    if ($ValidateOnly) {
        $status = if ($exists) { "EXISTS" } else { "MISSING" }
        $color = if ($exists) { "Green" } else { "Red" }
        Write-Host "  [$status] $($ref.DisplayName) ($($ref.SchemaName))" -ForegroundColor $color
        if ($exists) {
            Write-Host "    Connector: $($existingRefs[$ref.SchemaName].connectorid)" -ForegroundColor Gray
        }
        continue
    }

    if ($exists) {
        Write-Host "  [SKIP] $($ref.DisplayName) - already exists" -ForegroundColor Yellow
        $skipped++
        continue
    }

    Write-Host "  [CREATE] $($ref.DisplayName)..." -ForegroundColor Cyan

    try {
        $body = @{
            connectionreferencelogicalname = $ref.SchemaName
            connectionreferencedisplayname = $ref.DisplayName
            description                    = $ref.Description
            connectorid                    = $ref.ConnectorId
            statecode                      = 0
            statuscode                     = 1
        }

        Invoke-DV -Method POST -Path "connectionreferences" -Body $body | Out-Null
        Write-Host "    Created" -ForegroundColor Green
        Write-Host "    Connector: $($ref.ConnectorId)" -ForegroundColor Gray
        Write-Host "    Used by flows: $($ref.UsedByFlows)" -ForegroundColor Gray
        $created++
    }
    catch {
        $errMsg = $_.ErrorDetails.Message
        try {
            $parsed = $errMsg | ConvertFrom-Json
            Write-Host "    Error: $($parsed.error.message)" -ForegroundColor Red
        } catch {
            Write-Host "    Error: $errMsg" -ForegroundColor Red
        }
        $errors++
    }
}

# ============================================================
# SUMMARY
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total: $($connectionRefs.Count)" -ForegroundColor White

if ($ValidateOnly) {
    $found = ($connectionRefs | Where-Object { $existingRefs.ContainsKey($_.SchemaName) }).Count
    Write-Host "Found: $found" -ForegroundColor Green
    Write-Host "Missing: $($connectionRefs.Count - $found)" -ForegroundColor $(if ($found -lt $connectionRefs.Count) { "Red" } else { "Green" })
} else {
    Write-Host "Created: $created" -ForegroundColor Green
    Write-Host "Skipped: $skipped" -ForegroundColor Yellow
    Write-Host "Errors: $errors" -ForegroundColor $(if ($errors -gt 0) { "Red" } else { "Green" })
}

if (!$ValidateOnly -and $errors -eq 0) {
    Write-Host "`nIMPORTANT: Connection references are created but NOT YET LINKED to actual connections." -ForegroundColor Yellow
    Write-Host "You must link them manually in the Maker Portal:" -ForegroundColor Yellow
    Write-Host "  1. Open make.powerapps.com > Solutions > DoD8140CWFCompliance" -ForegroundColor White
    Write-Host "  2. Add existing > Connection reference > Select all 5 cwf_ refs" -ForegroundColor White
    Write-Host "  3. Click each connection reference > Set the Connection dropdown" -ForegroundColor White
    Write-Host "     (Create new connections if needed when prompted)" -ForegroundColor White
    Write-Host "  4. Validate: .\CWF-CREATE-CONNECTION-REFERENCES.ps1 ... -ValidateOnly" -ForegroundColor White
}
