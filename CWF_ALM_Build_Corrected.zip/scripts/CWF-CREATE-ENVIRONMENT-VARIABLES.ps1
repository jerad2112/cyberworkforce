# CWF-CREATE-ENVIRONMENT-VARIABLES.ps1
# Creates environment variables in Dataverse for CWF solution using the Dataverse Web API
# Usage: .\CWF-CREATE-ENVIRONMENT-VARIABLES.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"
#
# CORRECTED: Uses Dataverse Web API (Invoke-RestMethod) instead of non-existent pac CLI subcommands.
# pac CLI does NOT have: add-environment-variable, list-environment-variables, data query

param(
    [Parameter(Mandatory=$true, HelpMessage="Dataverse environment URL (e.g. https://orge0291f5f.crm.dynamics.com)")]
    [string]$EnvironmentUrl,

    [Parameter(Mandatory=$false)]
    [string]$SolutionName = "DoD8140CWFCompliance",

    [Parameter(Mandatory=$false)]
    [switch]$ValidateOnly,

    [Parameter(Mandatory=$false, HelpMessage="OAuth access token. If omitted, script attempts pac auth.")]
    [string]$AccessToken
)

#Requires -Version 5.1

$ErrorActionPreference = "Stop"

# ============================================================
# HELPER: Get Dataverse access token via interactive device code flow
# Works with PowerShell 5.1, no extra modules required
# ============================================================
function Get-DataverseToken {
    param([string]$EnvUrl)

    if ($AccessToken) { return $AccessToken }

    # Use the well-known "Microsoft Azure PowerShell" client ID (available on all tenants)
    $clientId = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $resource = "$($EnvUrl.TrimEnd('/'))/"
    $tenantId = "common"

    Write-Host "  Requesting device code for authentication..." -ForegroundColor Yellow

    # Step 1: Request device code
    $deviceCodeBody = @{
        client_id = $clientId
        resource  = $resource
    }

    try {
        $deviceCodeResponse = Invoke-RestMethod -Method POST `
            -Uri "https://login.microsoftonline.com/$tenantId/oauth2/devicecode" `
            -Body $deviceCodeBody `
            -ContentType "application/x-www-form-urlencoded"
    }
    catch {
        throw "Failed to request device code: $_"
    }

    # Step 2: Show the user the code and URL
    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host "  To sign in, open a browser and go to:" -ForegroundColor White
    Write-Host "    $($deviceCodeResponse.verification_url)" -ForegroundColor Yellow
    Write-Host "  Enter the code:" -ForegroundColor White
    Write-Host "    $($deviceCodeResponse.user_code)" -ForegroundColor Green
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Waiting for authentication..." -ForegroundColor Gray

    # Step 3: Poll for token
    $tokenBody = @{
        grant_type  = "urn:ietf:params:oauth:grant-type:device_code"
        client_id   = $clientId
        code        = $deviceCodeResponse.device_code
    }

    $interval = [int]$deviceCodeResponse.interval
    if ($interval -lt 5) { $interval = 5 }
    $deadline = (Get-Date).AddSeconds([int]$deviceCodeResponse.expires_in)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tokenResponse = Invoke-RestMethod -Method POST `
                -Uri "https://login.microsoftonline.com/$tenantId/oauth2/token" `
                -Body $tokenBody `
                -ContentType "application/x-www-form-urlencoded"

            Write-Host "  Authenticated successfully!" -ForegroundColor Green
            return $tokenResponse.access_token
        }
        catch {
            $errorMsg = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($errorMsg.error -eq "authorization_pending") {
                # Still waiting for user, keep polling
                continue
            }
            elseif ($errorMsg.error -eq "slow_down") {
                $interval += 5
                continue
            }
            else {
                throw "Authentication failed: $($errorMsg.error_description)"
            }
        }
    }

    throw "Authentication timed out. Please try again."
}

# ============================================================
# HELPER: Invoke Dataverse Web API
# ============================================================
function Invoke-DataverseApi {
    param(
        [string]$Method = "GET",
        [string]$Uri,
        [object]$Body,
        [string]$Token
    )

    $headers = @{
        "Authorization"    = "Bearer $Token"
        "OData-MaxVersion" = "4.0"
        "OData-Version"    = "4.0"
        "Accept"           = "application/json"
        "Content-Type"     = "application/json; charset=utf-8"
        "Prefer"           = "odata.include-annotations=*"
    }

    $params = @{
        Method  = $Method
        Uri     = $Uri
        Headers = $headers
    }

    if ($Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 10)
    }

    return Invoke-RestMethod @params
}

# ============================================================
# MAIN
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Environment Variable Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $EnvironmentUrl" -ForegroundColor White
Write-Host "Solution: $SolutionName" -ForegroundColor White
Write-Host "Mode: $(if ($ValidateOnly) { 'VALIDATION ONLY' } else { 'CREATE' })" -ForegroundColor Yellow
Write-Host ""

$apiBase = "$($EnvironmentUrl.TrimEnd('/'))/api/data/v9.2"

# Get token
$token = Get-DataverseToken -EnvUrl $EnvironmentUrl
Write-Host "Authenticated to Dataverse." -ForegroundColor Green

# Environment Variables Definition (matches environment-variables.json)
$environmentVariables = @(
    @{SchemaName="cwf_AuditRetentionDays"; DisplayName="Audit Retention Days"; Type=100000001; DefaultValue="365"; Description="STIG audit log retention period in days"},
    @{SchemaName="cwf_ComplianceThreshold"; DisplayName="Compliance Threshold"; Type=100000001; DefaultValue="85"; Description="Minimum compliance score for Green status"},
    @{SchemaName="cwf_TrainingGracePeriodDays"; DisplayName="Training Grace Period Days"; Type=100000001; DefaultValue="30"; Description="Grace period after training expiration"},
    @{SchemaName="cwf_CERenewalWarningDays"; DisplayName="CE Renewal Warning Days"; Type=100000001; DefaultValue="60"; Description="Days before CE renewal to send warning"},
    @{SchemaName="cwf_DefaultCPDHours"; DisplayName="Default CPD Hours"; Type=100000001; DefaultValue="20"; Description="Default CPD hours required"},
    @{SchemaName="cwf_ImportBatchSize"; DisplayName="Import Batch Size"; Type=100000001; DefaultValue="500"; Description="Number of records per batch during imports"},
    @{SchemaName="cwf_ScoreRAGThresholdGreen"; DisplayName="RAG Green Threshold"; Type=100000001; DefaultValue="85"; Description="Score threshold for Green RAG status"},
    @{SchemaName="cwf_ScoreRAGThresholdAmber"; DisplayName="RAG Amber Threshold"; Type=100000001; DefaultValue="60"; Description="Score threshold for Amber RAG status"},
    @{SchemaName="cwf_ExpiringWarningDays"; DisplayName="Expiring Warning Days"; Type=100000001; DefaultValue="60"; Description="Days before expiration for warning notifications"},
    @{SchemaName="cwf_CriticalWarningDays"; DisplayName="Critical Warning Days"; Type=100000001; DefaultValue="14"; Description="Days before expiration for critical alerts"},
    @{SchemaName="cwf_SessionTimeoutMinutes"; DisplayName="Session Timeout Minutes"; Type=100000001; DefaultValue="15"; Description="User session timeout (STIG V-222432)"},
    @{SchemaName="cwf_BannerVersion"; DisplayName="Banner Version"; Type=100000000; DefaultValue="1.0"; Description="DoD consent banner version (STIG V-222399/V-222400)"},
    @{SchemaName="cwf_SAARExpirationDays"; DisplayName="SAAR Expiration Days"; Type=100000001; DefaultValue="365"; Description="SAAR validity period in days (AR 25-2)"},
    @{SchemaName="cwf_NetworkRoleInheritanceDepth"; DisplayName="Network Role Inheritance Depth"; Type=100000001; DefaultValue="3"; Description="Maximum depth for role inheritance"},
    @{SchemaName="cwf_MaxConcurrentSessions"; DisplayName="Max Concurrent Sessions"; Type=100000001; DefaultValue="3"; Description="Maximum concurrent user sessions (STIG V-222430)"},
    @{SchemaName="cwf_MaxConcurrentPersonnel"; DisplayName="Max Concurrent Personnel"; Type=100000001; DefaultValue="20"; Description="Max concurrent personnel processing in Flow 011"},
    @{SchemaName="cwf_MaxConcurrentRequirements"; DisplayName="Max Concurrent Requirements"; Type=100000001; DefaultValue="5"; Description="Max concurrent requirement processing in Flow 011"},
    @{SchemaName="cwf_ComplianceWarningDays"; DisplayName="Compliance Warning Days"; Type=100000001; DefaultValue="60"; Description="Days before expiration for compliance warnings"},
    @{SchemaName="cwf_ComplianceCriticalDays"; DisplayName="Compliance Critical Days"; Type=100000001; DefaultValue="14"; Description="Days before expiration for critical compliance alerts"},
    @{SchemaName="cwf_NotificationEmailFrom"; DisplayName="Notification Email From"; Type=100000000; DefaultValue="cwf-noreply@army.mil"; Description="From address for system notifications"},
    @{SchemaName="cwf_SupportEmail"; DisplayName="Support Email"; Type=100000000; DefaultValue="cwf-support@army.mil"; Description="Support contact email"},
    @{SchemaName="cwf_GraphAPIEndpoint"; DisplayName="Graph API Endpoint"; Type=100000000; DefaultValue="https://graph.microsoft.us"; Description="Microsoft Graph API endpoint (GCC High)"},
    @{SchemaName="cwf_AzureStorageAccountName"; DisplayName="Azure Storage Account Name"; Type=100000000; DefaultValue=""; Description="Azure Blob Storage account for Vantage sync"},
    @{SchemaName="cwf_SharePointSiteUrl"; DisplayName="SharePoint Site URL"; Type=100000000; DefaultValue=""; Description="SharePoint site for document storage"},
    @{SchemaName="cwf_EnvironmentType"; DisplayName="Environment Type"; Type=100000000; DefaultValue="DEV"; Description="Environment type: DEV, TEST, or PROD"}
)
# Type codes: 100000000 = String, 100000001 = Number, 100000002 = Boolean, 100000003 = JSON

# ============================================================
# QUERY: Check which env vars already exist
# ============================================================
Write-Host "Querying existing environment variables..." -ForegroundColor Yellow

$existingVars = @{}
try {
    $query = "$apiBase/environmentvariabledefinitions?`$select=schemaname,displayname,environmentvariabledefinitionid&`$filter=startswith(schemaname,'cwf_')"
    $result = Invoke-DataverseApi -Uri $query -Token $token
    foreach ($ev in $result.value) {
        $existingVars[$ev.schemaname] = $ev.environmentvariabledefinitionid
    }
    Write-Host "  Found $($existingVars.Count) existing cwf_ environment variables" -ForegroundColor Gray
}
catch {
    Write-Host "  Warning: Could not query existing variables: $_" -ForegroundColor Yellow
}

# ============================================================
# VALIDATE or CREATE
# ============================================================
$results = @()
$createdCount = 0
$skippedCount = 0
$missingCount = 0
$errorCount = 0

foreach ($var in $environmentVariables) {
    $exists = $existingVars.ContainsKey($var.SchemaName)

    if ($ValidateOnly) {
        if ($exists) {
            $results += [PSCustomObject]@{ SchemaName=$var.SchemaName; DisplayName=$var.DisplayName; Status="EXISTS"; Id=$existingVars[$var.SchemaName] }
            Write-Host "  [EXISTS] $($var.SchemaName)" -ForegroundColor Green
        } else {
            $results += [PSCustomObject]@{ SchemaName=$var.SchemaName; DisplayName=$var.DisplayName; Status="MISSING"; Id="" }
            Write-Host "  [MISSING] $($var.SchemaName)" -ForegroundColor Red
            $missingCount++
        }
        continue
    }

    # CREATE mode
    if ($exists) {
        Write-Host "  [SKIP] $($var.SchemaName) already exists" -ForegroundColor Yellow
        $skippedCount++
        $results += [PSCustomObject]@{ SchemaName=$var.SchemaName; DisplayName=$var.DisplayName; Status="SKIPPED"; Id=$existingVars[$var.SchemaName] }
        continue
    }

    Write-Host "  [CREATE] $($var.SchemaName)" -ForegroundColor Cyan

    try {
        # Step 1: Create the environment variable definition
        $body = @{
            schemaname  = $var.SchemaName
            displayname = $var.DisplayName
            description = $var.Description
            type        = $var.Type
            defaultvalue = $var.DefaultValue
        }

        $created = Invoke-DataverseApi -Method POST -Uri "$apiBase/environmentvariabledefinitions" -Body $body -Token $token

        # Step 2: Create the default value record
        if ($var.DefaultValue -and $created.environmentvariabledefinitionid) {
            $valueBody = @{
                value = $var.DefaultValue
                "EnvironmentVariableDefinitionId@odata.bind" = "/environmentvariabledefinitions($($created.environmentvariabledefinitionid))"
            }
            Invoke-DataverseApi -Method POST -Uri "$apiBase/environmentvariablevalues" -Body $valueBody -Token $token | Out-Null
        }

        Write-Host "    Created successfully" -ForegroundColor Green
        $createdCount++
        $results += [PSCustomObject]@{ SchemaName=$var.SchemaName; DisplayName=$var.DisplayName; Status="CREATED"; Id=$created.environmentvariabledefinitionid }
    }
    catch {
        Write-Host "    Error: $_" -ForegroundColor Red
        $errorCount++
        $results += [PSCustomObject]@{ SchemaName=$var.SchemaName; DisplayName=$var.DisplayName; Status="ERROR"; Id=$_.Exception.Message }
    }
}

# ============================================================
# SUMMARY
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Variables: $($environmentVariables.Count)" -ForegroundColor White

if ($ValidateOnly) {
    Write-Host "Found: $($environmentVariables.Count - $missingCount)" -ForegroundColor Green
    Write-Host "Missing: $missingCount" -ForegroundColor $(if ($missingCount -gt 0) { "Red" } else { "Green" })
} else {
    Write-Host "Created: $createdCount" -ForegroundColor Green
    Write-Host "Skipped (existing): $skippedCount" -ForegroundColor Yellow
    Write-Host "Errors: $errorCount" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })
}

# Export results
$results | Export-Csv -Path "EnvironmentVariable_Results.csv" -NoTypeInformation
Write-Host "`nResults saved to: EnvironmentVariable_Results.csv" -ForegroundColor Cyan

if ($ValidateOnly -and $missingCount -eq 0) {
    Write-Host "`nALL ENVIRONMENT VARIABLES VALIDATED!" -ForegroundColor Green
    exit 0
} elseif ($ValidateOnly) {
    Write-Host "`nVALIDATION FAILED - Missing $missingCount variables" -ForegroundColor Red
    exit 1
} elseif ($errorCount -eq 0) {
    Write-Host "`nENVIRONMENT VARIABLE SETUP COMPLETE!" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`nSETUP COMPLETE WITH ERRORS - Review results" -ForegroundColor Yellow
    exit 1
}
