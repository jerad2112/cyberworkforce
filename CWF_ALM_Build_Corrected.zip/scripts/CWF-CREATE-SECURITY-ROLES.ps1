# CWF-CREATE-SECURITY-ROLES.ps1
# Creates 8 CWF security roles with table-level privileges for all 22 tables
# Usage: .\CWF-CREATE-SECURITY-ROLES.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"
#
# Roles: System Admin, ISSM, ISSO, Supervisor, Member, Read Only, Import User, Auditor

param(
    [Parameter(Mandatory=$true)]
    [string]$EnvironmentUrl,
    [Parameter(Mandatory=$false)]
    [string]$AccessToken,
    [Parameter(Mandatory=$false)]
    [switch]$ValidateOnly
)

#Requires -Version 5.1
$ErrorActionPreference = "Stop"

# ============================================================
# AUTH: Device code flow
# ============================================================
function Get-Token {
    param([string]$EnvUrl)
    if ($AccessToken) { return $AccessToken }
    $cid = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $res = "$($EnvUrl.TrimEnd('/'))/"
    Write-Host "  Requesting device code..." -ForegroundColor Yellow
    $dcr = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/common/oauth2/devicecode" `
        -Body @{ client_id = $cid; resource = $res } -ContentType "application/x-www-form-urlencoded"
    Write-Host "  Go to: $($dcr.verification_url)" -ForegroundColor Yellow
    Write-Host "  Code:  $($dcr.user_code)" -ForegroundColor Green
    Write-Host "  Waiting..." -ForegroundColor Gray
    $tb = @{ grant_type = "urn:ietf:params:oauth:grant-type:device_code"; client_id = $cid; code = $dcr.device_code }
    $iv = [Math]::Max([int]$dcr.interval, 5)
    $dl = (Get-Date).AddSeconds([int]$dcr.expires_in)
    while ((Get-Date) -lt $dl) {
        Start-Sleep -Seconds $iv
        try {
            $tr = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/common/oauth2/token" -Body $tb -ContentType "application/x-www-form-urlencoded"
            Write-Host "  Authenticated!" -ForegroundColor Green
            return $tr.access_token
        } catch {
            $e = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($e.error -eq "authorization_pending") { continue }
            elseif ($e.error -eq "slow_down") { $iv += 5; continue }
            else { throw "Auth failed: $($e.error_description)" }
        }
    }
    throw "Timed out."
}

# ============================================================
# API helpers
# ============================================================
function Invoke-DV {
    param([string]$Method = "GET", [string]$Path, [object]$Body)
    $uri = "$script:apiBase/$Path"
    $p = @{ Method = $Method; Uri = $uri; Headers = $script:headers }
    if ($Body) {
        $p.Body = ($Body | ConvertTo-Json -Depth 20)
        $p.ContentType = "application/json; charset=utf-8"
    }
    return Invoke-RestMethod @p
}

# ============================================================
# PRIVILEGE DEPTH CONSTANTS
# Dataverse uses string depth values in AddPrivilegesRole:
#   "Basic" = User (own records)
#   "Local" = Business Unit
#   "Deep"  = Parent:Child BU
#   "Global" = Organization (all records)
# ============================================================
$DEPTH_NONE   = "None"
$DEPTH_USER   = "Basic"
$DEPTH_BU     = "Local"
$DEPTH_PARENT = "Deep"
$DEPTH_ORG    = "Global"

# ============================================================
# ROLE DEFINITIONS with privilege matrix
# C=Create, R=Read, W=Write, D=Delete, Ap=Append, ApTo=AppendTo
# ============================================================
# Privilege access levels per role per table category
# Categories: Reference, Core, DynamicTraining, Operational, System

$roleDefinitions = @(
    @{
        Name = "CWF System Admin"
        Description = "Full access to all CWF tables and configuration. For G-6 system administrators."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_ORG; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Core            = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_ORG; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            DynamicTraining = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_ORG; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Operational     = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_ORG; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            System          = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_ORG; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
        }
    },
    @{
        Name = "CWF ISSM"
        Description = "Information System Security Manager. Full read, create/write on operational and compliance tables."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Core            = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            DynamicTraining = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Operational     = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_ORG; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            System          = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
        }
    },
    @{
        Name = "CWF ISSO"
        Description = "Information System Security Officer. Read all, create/write operational tables within business unit."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Core            = @{ Create=$DEPTH_BU; Read=$DEPTH_ORG; Write=$DEPTH_BU; Delete=$DEPTH_NONE; Append=$DEPTH_BU; AppendTo=$DEPTH_BU }
            DynamicTraining = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Operational     = @{ Create=$DEPTH_BU; Read=$DEPTH_ORG; Write=$DEPTH_BU; Delete=$DEPTH_NONE; Append=$DEPTH_BU; AppendTo=$DEPTH_BU }
            System          = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
        }
    },
    @{
        Name = "CWF Supervisor"
        Description = "Supervisors who approve training and review compliance for their team."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Core            = @{ Create=$DEPTH_NONE; Read=$DEPTH_BU; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_BU; AppendTo=$DEPTH_BU }
            DynamicTraining = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Operational     = @{ Create=$DEPTH_NONE; Read=$DEPTH_BU; Write=$DEPTH_BU; Delete=$DEPTH_NONE; Append=$DEPTH_BU; AppendTo=$DEPTH_BU }
            System          = @{ Create=$DEPTH_NONE; Read=$DEPTH_BU; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_BU; AppendTo=$DEPTH_BU }
        }
    },
    @{
        Name = "CWF Member"
        Description = "Standard workforce member. View own records, submit training and certifications."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_USER; AppendTo=$DEPTH_USER }
            Core            = @{ Create=$DEPTH_NONE; Read=$DEPTH_USER; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_USER; AppendTo=$DEPTH_USER }
            DynamicTraining = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_USER; AppendTo=$DEPTH_USER }
            Operational     = @{ Create=$DEPTH_USER; Read=$DEPTH_USER; Write=$DEPTH_USER; Delete=$DEPTH_NONE; Append=$DEPTH_USER; AppendTo=$DEPTH_USER }
            System          = @{ Create=$DEPTH_NONE; Read=$DEPTH_USER; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_USER; AppendTo=$DEPTH_USER }
        }
    },
    @{
        Name = "CWF Read Only"
        Description = "Read-only access to all CWF data. For leadership dashboards and reporting."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            Core            = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            DynamicTraining = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            Operational     = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            System          = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
        }
    },
    @{
        Name = "CWF Import User"
        Description = "Service account role for Army Vantage data sync and bulk imports."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Core            = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            DynamicTraining = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            Operational     = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
            System          = @{ Create=$DEPTH_ORG; Read=$DEPTH_ORG; Write=$DEPTH_ORG; Delete=$DEPTH_NONE; Append=$DEPTH_ORG; AppendTo=$DEPTH_ORG }
        }
    },
    @{
        Name = "CWF Auditor"
        Description = "Read-only access with full audit log visibility. For IG and compliance auditors."
        Privileges = @{
            Reference       = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            Core            = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            DynamicTraining = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            Operational     = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
            System          = @{ Create=$DEPTH_NONE; Read=$DEPTH_ORG; Write=$DEPTH_NONE; Delete=$DEPTH_NONE; Append=$DEPTH_NONE; AppendTo=$DEPTH_NONE }
        }
    }
)

# Table-to-category mapping
$tableCategories = @{
    "cwf_dcwfworkrole"          = "Reference"
    "cwf_approvedcert"          = "Reference"
    "cwf_wrcmapping"            = "Reference"
    "cwf_organization"          = "Core"
    "cwf_position"              = "Core"
    "cwf_personnel"             = "Core"
    "cwf_networkrole"           = "DynamicTraining"
    "cwf_trainingdefinition"    = "DynamicTraining"
    "cwf_roletrainingreq"       = "DynamicTraining"
    "cwf_roledocumentreq"       = "DynamicTraining"
    "cwf_orgrequirementoverride"= "DynamicTraining"
    "cwf_training"              = "Operational"
    "cwf_qualification"         = "Operational"
    "cwf_certification"         = "Operational"
    "cwf_saar"                  = "Operational"
    "cwf_appointmentorder"      = "Operational"
    "cwf_experienceeval"        = "Operational"
    "cwf_delegation"            = "Operational"
    "cwf_compliancescore"       = "System"
    "cwf_requirementsconfig"    = "System"
    "cwf_importhistory"         = "System"
    "cwf_auditlog"              = "System"
}

# Privilege name prefixes
$privPrefixes = @{
    Create   = "prvCreate"
    Read     = "prvRead"
    Write    = "prvWrite"
    Delete   = "prvDelete"
    Append   = "prvAppend"
    AppendTo = "prvAppendTo"
}

# ============================================================
# MAIN
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Security Role Builder" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $EnvironmentUrl" -ForegroundColor White
Write-Host "Mode: $(if ($ValidateOnly) { 'VALIDATE ONLY' } else { 'CREATE' })" -ForegroundColor Yellow
Write-Host "Roles: $($roleDefinitions.Count)" -ForegroundColor White
Write-Host "Tables: $($tableCategories.Count)" -ForegroundColor White
Write-Host ""

$script:apiBase = "$($EnvironmentUrl.TrimEnd('/'))/api/data/v9.2"
$token = Get-Token -EnvUrl $EnvironmentUrl
$script:headers = @{
    "Authorization" = "Bearer $token"
    "OData-MaxVersion" = "4.0"; "OData-Version" = "4.0"
    "Accept" = "application/json"
}

# ============================================================
# Step 1: Get the root Business Unit (required for role creation)
# ============================================================
Write-Host "Getting root Business Unit..." -ForegroundColor Yellow
$buResult = Invoke-DV -Path "businessunits?`$select=businessunitid,name&`$filter=parentbusinessunitid eq null"
$rootBuId = $buResult.value[0].businessunitid
Write-Host "  Root BU: $($buResult.value[0].name) ($rootBuId)" -ForegroundColor Gray

# ============================================================
# Step 2: Get existing roles
# ============================================================
Write-Host "Checking existing CWF roles..." -ForegroundColor Yellow
$existingRoles = @{}
$roleResult = Invoke-DV -Path "roles?`$select=roleid,name&`$filter=_businessunitid_value eq '$rootBuId'"
foreach ($role in $roleResult.value) {
    if ($role.name -like "CWF *") {
        $existingRoles[$role.name] = $role.roleid
    }
}
Write-Host "  Found $($existingRoles.Count) existing CWF roles" -ForegroundColor Gray

# ============================================================
# Step 3: Get privilege IDs for all CWF tables
# ============================================================
Write-Host "Loading privilege IDs for $($tableCategories.Count) tables..." -ForegroundColor Yellow

$tablePrivileges = @{}  # tableName -> @{ Create=guid; Read=guid; Write=guid; Delete=guid; Append=guid; AppendTo=guid }

foreach ($tableName in $tableCategories.Keys) {
    try {
        $privResult = Invoke-DV -Path "EntityDefinitions(LogicalName='$tableName')/Privileges"
        $privMap = @{}
        foreach ($priv in $privResult.value) {
            foreach ($prefix in $privPrefixes.GetEnumerator()) {
                if ($priv.Name -like "$($prefix.Value)*") {
                    $privMap[$prefix.Key] = $priv.PrivilegeId
                    break
                }
            }
        }
        $tablePrivileges[$tableName] = $privMap
        Write-Host "  $tableName : $($privMap.Count) privileges" -ForegroundColor Gray
    }
    catch {
        Write-Host "  $tableName : Failed to load privileges - $_" -ForegroundColor Red
    }
}

# ============================================================
# Step 4: Create roles and assign privileges
# ============================================================
Write-Host "`nCreating security roles..." -ForegroundColor Yellow

$rolesCreated = 0
$rolesSkipped = 0
$rolesError = 0
$totalPrivsAssigned = 0

foreach ($roleDef in $roleDefinitions) {
    $roleName = $roleDef.Name

    if ($ValidateOnly) {
        $status = if ($existingRoles.ContainsKey($roleName)) { "EXISTS" } else { "MISSING" }
        $color = if ($status -eq "EXISTS") { "Green" } else { "Red" }
        Write-Host "  [$status] $roleName" -ForegroundColor $color
        continue
    }

    if ($existingRoles.ContainsKey($roleName)) {
        Write-Host "  [SKIP] $roleName (already exists)" -ForegroundColor Yellow
        $rolesSkipped++

        # Still assign privileges in case they were updated
        $roleId = $existingRoles[$roleName]
    }
    else {
        Write-Host "  [CREATE] $roleName..." -ForegroundColor Cyan

        try {
            $roleBody = @{
                name = $roleName
                description = $roleDef.Description
                "businessunitid@odata.bind" = "/businessunits($rootBuId)"
            }
            $createResult = Invoke-DV -Method POST -Path "roles" -Body $roleBody

            # Extract role ID from the response or OData-EntityId header
            # The POST returns the created entity
            $roleId = $null

            # Query back to get the ID
            $findRole = Invoke-DV -Path "roles?`$select=roleid&`$filter=name eq '$roleName' and _businessunitid_value eq '$rootBuId'"
            if ($findRole.value.Count -gt 0) {
                $roleId = $findRole.value[0].roleid
            }

            if ($roleId) {
                Write-Host "    Created (ID: $roleId)" -ForegroundColor Green
                $rolesCreated++
            } else {
                Write-Host "    Created but could not retrieve ID" -ForegroundColor Yellow
                $rolesCreated++
                continue
            }
        }
        catch {
            $errMsg = $_.ErrorDetails.Message
            try {
                $parsed = $errMsg | ConvertFrom-Json
                Write-Host "    Error: $($parsed.error.message)" -ForegroundColor Red
            } catch {
                Write-Host "    Error: $errMsg" -ForegroundColor Red
            }
            $rolesError++
            continue
        }
    }

    # ============================================================
    # Assign privileges to this role
    # ============================================================
    if ($roleId) {
        Write-Host "    Assigning privileges..." -ForegroundColor Gray

        $privilegesToAdd = @()

        foreach ($tableName in $tableCategories.Keys) {
            $category = $tableCategories[$tableName]
            $privLevels = $roleDef.Privileges[$category]
            $tblPrivs = $tablePrivileges[$tableName]

            if (!$tblPrivs) { continue }

            foreach ($op in @("Create", "Read", "Write", "Delete", "Append", "AppendTo")) {
                $depth = $privLevels[$op]
                if ($depth -eq $DEPTH_NONE) { continue }

                $privId = $tblPrivs[$op]
                if (!$privId) { continue }

                $privilegesToAdd += @{
                    PrivilegeId = $privId
                    Depth = $depth
                }
            }
        }

        if ($privilegesToAdd.Count -gt 0) {
            try {
                $addPrivBody = @{
                    Privileges = $privilegesToAdd
                }
                Invoke-DV -Method POST -Path "roles($roleId)/Microsoft.Dynamics.CRM.AddPrivilegesRole" -Body $addPrivBody
                Write-Host "    Assigned $($privilegesToAdd.Count) privileges" -ForegroundColor Green
                $totalPrivsAssigned += $privilegesToAdd.Count
            }
            catch {
                $errMsg = $_.ErrorDetails.Message
                try {
                    $parsed = $errMsg | ConvertFrom-Json
                    Write-Host "    Privilege assignment error: $($parsed.error.message)" -ForegroundColor Red
                } catch {
                    Write-Host "    Privilege assignment error: $errMsg" -ForegroundColor Red
                }
            }
        }
    }
}

# ============================================================
# SUMMARY
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Roles: $($roleDefinitions.Count)" -ForegroundColor White

if ($ValidateOnly) {
    $found = ($roleDefinitions | Where-Object { $existingRoles.ContainsKey($_.Name) }).Count
    $missing = $roleDefinitions.Count - $found
    Write-Host "Found: $found" -ForegroundColor Green
    Write-Host "Missing: $missing" -ForegroundColor $(if ($missing -gt 0) { "Red" } else { "Green" })
} else {
    Write-Host "Created: $rolesCreated" -ForegroundColor Green
    Write-Host "Skipped: $rolesSkipped" -ForegroundColor Yellow
    Write-Host "Errors: $rolesError" -ForegroundColor $(if ($rolesError -gt 0) { "Red" } else { "Green" })
    Write-Host "Privileges Assigned: $totalPrivsAssigned" -ForegroundColor Cyan
}

Write-Host "`nRole Privilege Matrix:" -ForegroundColor Yellow
Write-Host "  System Admin : Full CRUD on all 22 tables (Organization scope)" -ForegroundColor White
Write-Host "  ISSM         : Full operational + read reference (Organization scope)" -ForegroundColor White
Write-Host "  ISSO         : Create/write operational (BU scope) + read all" -ForegroundColor White
Write-Host "  Supervisor   : Read BU + write operational (BU scope)" -ForegroundColor White
Write-Host "  Member       : Own records only + submit training/certs" -ForegroundColor White
Write-Host "  Read Only    : Read all tables (Organization scope)" -ForegroundColor White
Write-Host "  Import User  : Create/write for bulk imports (Organization scope)" -ForegroundColor White
Write-Host "  Auditor      : Read all + full audit log access" -ForegroundColor White

if (!$ValidateOnly) {
    Write-Host "`nNEXT STEPS:" -ForegroundColor Yellow
    Write-Host "  1. Open make.powerapps.com > Solutions > DoD8140CWFCompliance" -ForegroundColor White
    Write-Host "  2. Add existing > Security role > Select all 8 CWF roles" -ForegroundColor White
    Write-Host "  3. Validate: .\CWF-CREATE-SECURITY-ROLES.ps1 ... -ValidateOnly" -ForegroundColor White
    Write-Host "  4. Run deployment validation from parent dir:" -ForegroundColor White
    Write-Host "     .\scripts\CWF-VALIDATE-DEPLOYMENT.ps1 ... -EnvironmentName DEV -Detailed" -ForegroundColor White
}
