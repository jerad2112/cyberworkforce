# CWF-CREATE-TABLES.ps1
# Creates all 22 CWF Dataverse tables from the schema definition file
# Usage: .\CWF-CREATE-TABLES.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"
#
# Creates tables via Dataverse Web API EntityDefinitions endpoint.
# Handles: String, Memo, WholeNumber, Decimal, Boolean, Choice, DateOnly, DateTime, Lookup

param(
    [Parameter(Mandatory=$true, HelpMessage="Dataverse environment URL")]
    [string]$EnvironmentUrl,

    [Parameter(Mandatory=$false)]
    [string]$SchemaFile = "..\schema\cwf-dataverse-schema.json",

    [Parameter(Mandatory=$false, HelpMessage="OAuth access token. If omitted, uses device code flow.")]
    [string]$AccessToken,

    [Parameter(Mandatory=$false)]
    [switch]$ValidateOnly
)

#Requires -Version 5.1

$ErrorActionPreference = "Stop"

# ============================================================
# AUTH: Device code flow (same as env vars script)
# ============================================================
function Get-DataverseToken {
    param([string]$EnvUrl)
    if ($AccessToken) { return $AccessToken }

    $clientId = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $resource = "$($EnvUrl.TrimEnd('/'))/"

    Write-Host "  Requesting device code for authentication..." -ForegroundColor Yellow
    $dcr = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/common/oauth2/devicecode" `
        -Body @{ client_id = $clientId; resource = $resource } `
        -ContentType "application/x-www-form-urlencoded"

    Write-Host ""
    Write-Host "  To sign in, go to: $($dcr.verification_url)" -ForegroundColor Yellow
    Write-Host "  Enter the code:    $($dcr.user_code)" -ForegroundColor Green
    Write-Host "  Waiting..." -ForegroundColor Gray

    $tb = @{ grant_type = "urn:ietf:params:oauth:grant-type:device_code"; client_id = $clientId; code = $dcr.device_code }
    $interval = [Math]::Max([int]$dcr.interval, 5)
    $deadline = (Get-Date).AddSeconds([int]$dcr.expires_in)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tr = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/common/oauth2/token" -Body $tb -ContentType "application/x-www-form-urlencoded"
            Write-Host "  Authenticated!" -ForegroundColor Green
            return $tr.access_token
        }
        catch {
            $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($err.error -eq "authorization_pending") { continue }
            elseif ($err.error -eq "slow_down") { $interval += 5; continue }
            else { throw "Auth failed: $($err.error_description)" }
        }
    }
    throw "Authentication timed out."
}

# ============================================================
# HELPER: API call wrapper
# ============================================================
function Invoke-DV {
    param(
        [string]$Method = "GET",
        [string]$Path,
        [object]$Body,
        [hashtable]$Headers
    )
    $uri = "$script:apiBase/$Path"
    $params = @{ Method = $Method; Uri = $uri; Headers = $Headers }
    if ($Body) { $params.Body = ($Body | ConvertTo-Json -Depth 20); $params.ContentType = "application/json; charset=utf-8" }
    return Invoke-RestMethod @params
}

# ============================================================
# HELPER: Map schema types to Dataverse attribute metadata
# ============================================================
function Get-AttributeBody {
    param($col, $prefix)

    $schemaName = if ($col.logicalName.StartsWith("cwf_")) { $col.logicalName } else { "${prefix}_$($col.logicalName)" }

    $base = @{
        SchemaName = $schemaName
        DisplayName = @{ "@odata.type" = "Microsoft.Dynamics.CRM.Label"; LocalizedLabels = @(@{ "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"; Label = $col.displayName; LanguageCode = 1033 }) }
        RequiredLevel = @{ Value = if ($col.required) { "ApplicationRequired" } else { "None" }; CanBeChanged = $true }
    }

    if ($col.description) {
        $base.Description = @{ "@odata.type" = "Microsoft.Dynamics.CRM.Label"; LocalizedLabels = @(@{ "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"; Label = $col.description; LanguageCode = 1033 }) }
    }

    switch ($col.type) {
        "String" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
            $base.FormatName = @{ Value = "Text" }
            $base.MaxLength = if ($col.maxLength) { $col.maxLength } else { 200 }
            return $base
        }
        "Memo" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.MemoAttributeMetadata"
            $base.MaxLength = if ($col.maxLength) { $col.maxLength } else { 2000 }
            $base.Format = "TextArea"
            return $base
        }
        "WholeNumber" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.IntegerAttributeMetadata"
            $base.Format = "None"
            $base.MinValue = if ($null -ne $col.min) { $col.min } else { -2147483648 }
            $base.MaxValue = if ($null -ne $col.max) { $col.max } else { 2147483647 }
            return $base
        }
        "Decimal" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.DecimalAttributeMetadata"
            $base.Precision = if ($col.precision) { $col.precision } else { 2 }
            $base.MinValue = -100000000000
            $base.MaxValue = 100000000000
            return $base
        }
        "Boolean" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.BooleanAttributeMetadata"
            $base.OptionSet = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.BooleanOptionSetMetadata"
                TrueOption = @{ Value = 1; Label = @{ "@odata.type" = "Microsoft.Dynamics.CRM.Label"; LocalizedLabels = @(@{ "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"; Label = "Yes"; LanguageCode = 1033 }) } }
                FalseOption = @{ Value = 0; Label = @{ "@odata.type" = "Microsoft.Dynamics.CRM.Label"; LocalizedLabels = @(@{ "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"; Label = "No"; LanguageCode = 1033 }) } }
            }
            $defaultVal = if ($col.default -eq $true) { $true } else { $false }
            $base.DefaultValue = $defaultVal
            return $base
        }
        "DateOnly" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.DateTimeAttributeMetadata"
            $base.Format = "DateOnly"
            $base.DateTimeBehavior = @{ Value = "DateOnly" }
            return $base
        }
        "DateTime" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.DateTimeAttributeMetadata"
            $base.Format = "DateAndTime"
            $base.DateTimeBehavior = @{ Value = "UserLocal" }
            return $base
        }
        "Choice" {
            $base["@odata.type"] = "Microsoft.Dynamics.CRM.PicklistAttributeMetadata"
            $options = @()
            foreach ($opt in $col.options) {
                $options += @{
                    Value = $opt.value
                    Label = @{ "@odata.type" = "Microsoft.Dynamics.CRM.Label"; LocalizedLabels = @(@{ "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"; Label = $opt.label; LanguageCode = 1033 }) }
                }
            }
            $base.OptionSet = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.OptionSetMetadata"
                IsGlobal = $false
                OptionSetType = "Picklist"
                Options = $options
            }
            return $base
        }
        default {
            Write-Host "    Skipping unsupported type: $($col.type) for $($col.logicalName)" -ForegroundColor Yellow
            return $null
        }
    }
}

# ============================================================
# MAIN
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Dataverse Table Builder" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $EnvironmentUrl" -ForegroundColor White
Write-Host "Schema: $SchemaFile" -ForegroundColor White
Write-Host "Mode: $(if ($ValidateOnly) { 'VALIDATE ONLY' } else { 'CREATE' })" -ForegroundColor Yellow
Write-Host ""

# Load schema
if (!(Test-Path $SchemaFile)) {
    Write-Host "Schema file not found: $SchemaFile" -ForegroundColor Red
    exit 1
}
$schema = Get-Content $SchemaFile -Raw | ConvertFrom-Json
Write-Host "Loaded schema: $($schema.tables.Count) tables, publisher prefix: $($schema.schema.publisher_prefix)" -ForegroundColor Green

$script:apiBase = "$($EnvironmentUrl.TrimEnd('/'))/api/data/v9.2"
$token = Get-DataverseToken -EnvUrl $EnvironmentUrl

$headers = @{
    "Authorization"    = "Bearer $token"
    "OData-MaxVersion" = "4.0"
    "OData-Version"    = "4.0"
    "Accept"           = "application/json"
    "Prefer"           = "odata.include-annotations=*"
}

# ============================================================
# Check existing tables
# ============================================================
Write-Host "`nChecking existing tables..." -ForegroundColor Yellow

$existingTables = @{}
try {
    # Note: startswith doesn't work on EntityDefinitions - get all custom entities and filter client-side
    $entityResult = Invoke-DV -Path "EntityDefinitions?`$select=LogicalName&`$filter=IsCustomEntity eq true" -Headers $headers
    foreach ($e in $entityResult.value) {
        if ($e.LogicalName -like "cwf_*") {
            $existingTables[$e.LogicalName] = $true
        }
    }
    Write-Host "  Found $($existingTables.Count) existing cwf_ tables" -ForegroundColor Gray
}
catch {
    Write-Host "  Warning: Could not query existing tables, will attempt creation for all" -ForegroundColor Yellow
}

# ============================================================
# VALIDATE or CREATE tables
# ============================================================
$createdCount = 0
$skippedCount = 0
$errorCount = 0
$lookups = @()

# Sort tables by order
$sortedTables = $schema.tables | Sort-Object { $_.order }

foreach ($table in $sortedTables) {
    $exists = $existingTables.ContainsKey($table.logicalName)

    if ($ValidateOnly) {
        $status = if ($exists) { "EXISTS" } else { "MISSING" }
        $color = if ($exists) { "Green" } else { "Red" }
        Write-Host "  [$status] $($table.logicalName) ($($table.displayName))" -ForegroundColor $color
        continue
    }

    if ($exists) {
        Write-Host "  [SKIP] $($table.logicalName) already exists" -ForegroundColor Yellow
        $skippedCount++
        continue
    }

    Write-Host "  [CREATE] $($table.logicalName) ($($table.displayName))..." -ForegroundColor Cyan

    try {
        # Build the primary name attribute (MUST be first in Attributes array with IsPrimaryName=true)
        $primaryCol = $table.columns | Where-Object { $_.logicalName -eq $table.primaryColumn }
        $primaryMaxLen = if ($primaryCol -and $primaryCol.maxLength) { $primaryCol.maxLength } else { 200 }
        $primaryDisplayName = if ($primaryCol) { $primaryCol.displayName } else { "Name" }

        $primaryAttribute = @{
            "@odata.type" = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
            SchemaName = $table.primaryColumn
            MaxLength = $primaryMaxLen
            FormatName = @{ Value = "Text" }
            IsPrimaryName = $true
            RequiredLevel = @{ Value = "ApplicationRequired"; CanBeChanged = $true }
            DisplayName = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.Label"
                LocalizedLabels = @(@{
                    "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
                    Label = $primaryDisplayName
                    LanguageCode = 1033
                })
            }
        }

        # Build entity definition - primary attribute goes INSIDE Attributes array
        $entityBody = @{
            "@odata.type" = "Microsoft.Dynamics.CRM.EntityMetadata"
            SchemaName = $table.logicalName
            DisplayName = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.Label"
                LocalizedLabels = @(@{
                    "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
                    Label = $table.displayName
                    LanguageCode = 1033
                })
            }
            DisplayCollectionName = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.Label"
                LocalizedLabels = @(@{
                    "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
                    Label = $table.pluralName
                    LanguageCode = 1033
                })
            }
            Description = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.Label"
                LocalizedLabels = @(@{
                    "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
                    Label = $table.description
                    LanguageCode = 1033
                })
            }
            HasActivities = $false
            HasNotes = $false
            OwnershipType = "UserOwned"
            IsActivity = $false
            Attributes = @($primaryAttribute)
        }

        # Add non-lookup, non-primary columns to the Attributes array
        foreach ($col in $table.columns) {
            if ($col.type -eq "Lookup") {
                # Collect lookups for later (after all tables exist)
                $lookups += @{
                    SourceTable = $table.logicalName
                    TargetTable = $col.target
                    LookupColumn = $col.logicalName
                    DisplayName = $col.displayName
                    Required = [bool]$col.required
                }
                continue
            }

            # Skip the primary column (already defined as PrimaryAttribute above)
            if ($col.logicalName -eq $table.primaryColumn) { continue }

            $attrBody = Get-AttributeBody -col $col -prefix $schema.schema.publisher_prefix
            if ($attrBody) {
                $entityBody.Attributes += $attrBody
            }
        }

        # Create the entity
        $createHeaders = $headers.Clone()
        $createHeaders["Content-Type"] = "application/json; charset=utf-8"

        $jsonBody = $entityBody | ConvertTo-Json -Depth 30
        Invoke-RestMethod -Method POST -Uri "$script:apiBase/EntityDefinitions" -Headers $createHeaders -Body $jsonBody | Out-Null

        Write-Host "    Table created with $($entityBody.Attributes.Count) columns" -ForegroundColor Green
        $createdCount++
    }
    catch {
        $errMsg = $_.ErrorDetails.Message
        if ($errMsg) {
            try {
                $parsed = $errMsg | ConvertFrom-Json
                Write-Host "    Error: $($parsed.error.message)" -ForegroundColor Red
            }
            catch {
                Write-Host "    Error: $errMsg" -ForegroundColor Red
            }
        } else {
            Write-Host "    Error: $_" -ForegroundColor Red
        }
        $errorCount++
    }
}

# ============================================================
# CREATE LOOKUPS (relationships) - after all tables exist
# ============================================================
if (!$ValidateOnly -and $lookups.Count -gt 0) {
    Write-Host "`nCreating $($lookups.Count) lookup relationships..." -ForegroundColor Yellow

    $lookupCreated = 0
    $lookupSkipped = 0
    $lookupErrors = 0

    foreach ($lk in $lookups) {
        Write-Host "  $($lk.SourceTable).$($lk.LookupColumn) -> $($lk.TargetTable)" -ForegroundColor Gray

        try {
            $relationshipBody = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.OneToManyRelationshipMetadata"
                SchemaName = "$($lk.LookupColumn)_$($lk.TargetTable)"
                ReferencedEntity = $lk.TargetTable
                ReferencingEntity = $lk.SourceTable
                Lookup = @{
                    "@odata.type" = "Microsoft.Dynamics.CRM.LookupAttributeMetadata"
                    SchemaName = $lk.LookupColumn
                    DisplayName = @{
                        "@odata.type" = "Microsoft.Dynamics.CRM.Label"
                        LocalizedLabels = @(@{
                            "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
                            Label = $lk.DisplayName
                            LanguageCode = 1033
                        })
                    }
                    RequiredLevel = @{
                        Value = if ($lk.Required) { "ApplicationRequired" } else { "None" }
                        CanBeChanged = $true
                    }
                }
                CascadeConfiguration = @{
                    Assign = "NoCascade"
                    Delete = "RemoveLink"
                    Merge = "NoCascade"
                    Reparent = "NoCascade"
                    Share = "NoCascade"
                    Unshare = "NoCascade"
                }
            }

            $createHeaders = $headers.Clone()
            $createHeaders["Content-Type"] = "application/json; charset=utf-8"

            $jsonBody = $relationshipBody | ConvertTo-Json -Depth 20
            Invoke-RestMethod -Method POST -Uri "$script:apiBase/RelationshipDefinitions" -Headers $createHeaders -Body $jsonBody | Out-Null

            Write-Host "    Created" -ForegroundColor Green
            $lookupCreated++
        }
        catch {
            $errMsg = $_.ErrorDetails.Message
            if ($errMsg -and $errMsg -match "already exists") {
                Write-Host "    Already exists, skipping" -ForegroundColor Yellow
                $lookupSkipped++
            }
            else {
                try {
                    $parsed = $errMsg | ConvertFrom-Json
                    Write-Host "    Error: $($parsed.error.message)" -ForegroundColor Red
                }
                catch {
                    Write-Host "    Error: $errMsg" -ForegroundColor Red
                }
                $lookupErrors++
            }
        }
    }

    Write-Host "`nLookup Summary: Created=$lookupCreated, Skipped=$lookupSkipped, Errors=$lookupErrors" -ForegroundColor Cyan
}

# ============================================================
# SUMMARY
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Tables: $($sortedTables.Count)" -ForegroundColor White

if ($ValidateOnly) {
    $found = ($sortedTables | Where-Object { $existingTables.ContainsKey($_.logicalName) }).Count
    $missing = $sortedTables.Count - $found
    Write-Host "Found: $found" -ForegroundColor Green
    Write-Host "Missing: $missing" -ForegroundColor $(if ($missing -gt 0) { "Red" } else { "Green" })
} else {
    Write-Host "Created: $createdCount" -ForegroundColor Green
    Write-Host "Skipped: $skippedCount" -ForegroundColor Yellow
    Write-Host "Errors: $errorCount" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })
    Write-Host "Lookups: $($lookups.Count) total" -ForegroundColor White
}

if (!$ValidateOnly) {
    Write-Host "`nNEXT STEPS:" -ForegroundColor Yellow
    Write-Host "  1. Open make.powerapps.com and verify tables in your solution" -ForegroundColor White
    Write-Host "  2. Add all tables to the DoD8140CWFCompliance solution" -ForegroundColor White
    Write-Host "  3. Run: .\CWF-VALIDATE-DEPLOYMENT.ps1 to verify" -ForegroundColor White
}
