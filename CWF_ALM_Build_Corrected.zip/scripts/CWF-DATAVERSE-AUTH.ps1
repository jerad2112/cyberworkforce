# CWF-DATAVERSE-AUTH.ps1
# Shared authentication helper for CWF scripts
# Dot-source this file: . .\scripts\CWF-DATAVERSE-AUTH.ps1
#
# Provides:
#   Get-DataverseHeaders  - Returns authenticated headers for Dataverse Web API
#   Invoke-DataverseGet   - GET request helper
#   Invoke-DataversePatch - PATCH request helper
#   Invoke-DataversePost  - POST request helper

function Get-DataverseHeaders {
    <#
    .SYNOPSIS
        Returns authenticated headers for Dataverse Web API.
        Supports service principal (client credentials) or interactive pac CLI auth.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$EnvironmentUrl,

        [Parameter(Mandatory=$false)]
        [string]$AppId,

        [Parameter(Mandatory=$false)]
        [string]$ClientSecret,

        [Parameter(Mandatory=$false)]
        [string]$TenantId,

        [Parameter(Mandatory=$false)]
        [string]$AccessToken
    )

    # If token already provided, use it directly
    if ($AccessToken) {
        return @{
            "Authorization"    = "Bearer $AccessToken"
            "OData-MaxVersion" = "4.0"
            "OData-Version"    = "4.0"
            "Accept"           = "application/json"
            "Content-Type"     = "application/json; charset=utf-8"
            "Prefer"           = "odata.include-annotations=*"
        }
    }

    # Service principal auth (client credentials)
    if ($AppId -and $ClientSecret -and $TenantId) {
        $tokenBody = @{
            grant_type    = "client_credentials"
            client_id     = $AppId
            client_secret = $ClientSecret
            scope         = "$($EnvironmentUrl.TrimEnd('/'))//.default"
        }

        # GCC High uses login.microsoftonline.us
        $loginEndpoint = if ($EnvironmentUrl -match "crm9\.dynamics\.com") {
            "https://login.microsoftonline.us"
        } else {
            "https://login.microsoftonline.com"
        }

        $tokenUrl = "$loginEndpoint/$TenantId/oauth2/v2.0/token"
        $tokenResponse = Invoke-RestMethod -Method POST -Uri $tokenUrl -Body $tokenBody -ContentType "application/x-www-form-urlencoded"

        return @{
            "Authorization"    = "Bearer $($tokenResponse.access_token)"
            "OData-MaxVersion" = "4.0"
            "OData-Version"    = "4.0"
            "Accept"           = "application/json"
            "Content-Type"     = "application/json; charset=utf-8"
            "Prefer"           = "odata.include-annotations=*"
        }
    }

    # Fallback: interactive device code flow (PS 5.1 compatible, no extra modules)
    $clientId = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $resource = "$($EnvironmentUrl.TrimEnd('/'))/"

    Write-Host "  Requesting device code for authentication..." -ForegroundColor Yellow
    $deviceCodeResponse = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/common/oauth2/devicecode" `
        -Body @{ client_id = $clientId; resource = $resource } `
        -ContentType "application/x-www-form-urlencoded"

    Write-Host "  To sign in, go to: $($deviceCodeResponse.verification_url)" -ForegroundColor Yellow
    Write-Host "  Enter the code:    $($deviceCodeResponse.user_code)" -ForegroundColor Green

    $tokenBody = @{
        grant_type = "urn:ietf:params:oauth:grant-type:device_code"
        client_id  = $clientId
        code       = $deviceCodeResponse.device_code
    }
    $interval = [Math]::Max([int]$deviceCodeResponse.interval, 5)
    $deadline = (Get-Date).AddSeconds([int]$deviceCodeResponse.expires_in)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tokenResponse = Invoke-RestMethod -Method POST `
                -Uri "https://login.microsoftonline.com/common/oauth2/token" `
                -Body $tokenBody -ContentType "application/x-www-form-urlencoded"
            Write-Host "  Authenticated!" -ForegroundColor Green
            return @{
                "Authorization"    = "Bearer $($tokenResponse.access_token)"
                "OData-MaxVersion" = "4.0"
                "OData-Version"    = "4.0"
                "Accept"           = "application/json"
                "Content-Type"     = "application/json; charset=utf-8"
                "Prefer"           = "odata.include-annotations=*"
            }
        }
        catch {
            $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($err.error -eq "authorization_pending") { continue }
            elseif ($err.error -eq "slow_down") { $interval += 5; continue }
            else { throw "Auth failed: $($err.error_description)" }
        }
    }
    throw "Authentication timed out."
}

function Invoke-DataverseGet {
    param(
        [string]$ApiBase,
        [string]$Path,
        [hashtable]$Headers
    )
    return Invoke-RestMethod -Method GET -Uri "$ApiBase/$Path" -Headers $Headers
}

function Invoke-DataversePatch {
    param(
        [string]$ApiBase,
        [string]$Path,
        [object]$Body,
        [hashtable]$Headers
    )
    $json = $Body | ConvertTo-Json -Depth 10
    return Invoke-RestMethod -Method PATCH -Uri "$ApiBase/$Path" -Headers $Headers -Body $json
}

function Invoke-DataversePost {
    param(
        [string]$ApiBase,
        [string]$Path,
        [object]$Body,
        [hashtable]$Headers
    )
    $json = $Body | ConvertTo-Json -Depth 10
    return Invoke-RestMethod -Method POST -Uri "$ApiBase/$Path" -Headers $Headers -Body $json
}

Write-Host "CWF Dataverse Auth module loaded." -ForegroundColor Gray
