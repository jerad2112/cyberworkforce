# CWF-EXPORT-SOLUTION.ps1
# Exports and unpacks CWF solution for GitHub PowerApp Builder
# Usage: .\CWF-EXPORT-SOLUTION.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com" -SolutionName "DoD8140CWFCompliance"

param(
    [Parameter(Mandatory=$true, HelpMessage="Dataverse environment URL")]
    [string]$EnvironmentUrl,
    
    [Parameter(Mandatory=$false)]
    [string]$SolutionName = "DoD8140CWFCompliance",
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\solutions",
    
    [Parameter(Mandatory=$false)]
    [switch]$Managed,
    
    [Parameter(Mandatory=$false)]
    [switch]$IncludeVersionInName
)

#Requires -Version 5.1

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Solution Export and Unpack" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Source Environment: $EnvironmentUrl" -ForegroundColor White
Write-Host "Solution: $SolutionName" -ForegroundColor White
Write-Host "Output Path: $OutputPath" -ForegroundColor White
Write-Host "Managed: $Managed" -ForegroundColor White
Write-Host ""

# Create output directory
if (!(Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    Write-Host "Created output directory: $OutputPath" -ForegroundColor Green
}

$solutionDir = Join-Path $OutputPath $SolutionName
if (!(Test-Path $solutionDir)) {
    New-Item -ItemType Directory -Path $solutionDir -Force | Out-Null
}

# Authenticate
Write-Host "Authenticating to Dataverse..." -ForegroundColor Yellow
pac auth create --url $EnvironmentUrl

# Get solution version
Write-Host "`nRetrieving solution information..." -ForegroundColor Yellow
$solutionInfo = pac solution list --environment $EnvironmentUrl | Select-String $SolutionName

if (!$solutionInfo) {
    Write-Host "✗ Solution not found: $SolutionName" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Solution found" -ForegroundColor Green

# Determine file name
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$managedFlag = if ($Managed) { "_managed" } else { "_unmanaged" }
$versionFlag = if ($IncludeVersionInName) { "_$timestamp" } else { "" }
$zipFileName = "$SolutionName$versionFlag$managedFlag.zip"
$exportPath = Join-Path $solutionDir $zipFileName

# Export Solution
Write-Host "`nExporting solution..." -ForegroundColor Yellow
Write-Host "  File: $zipFileName" -ForegroundColor Gray

try {
    $managedParam = if ($Managed) { "--managed" } else { "" }
    
    pac solution export `
        --environment $EnvironmentUrl `
        --name $SolutionName `
        --path $exportPath `
        $managedParam
    
    if (Test-Path $exportPath) {
        $fileSize = [math]::Round((Get-Item $exportPath).Length / 1MB, 2)
        Write-Host "✓ Solution exported successfully" -ForegroundColor Green
        Write-Host "  Path: $exportPath" -ForegroundColor Gray
        Write-Host "  Size: $fileSize MB" -ForegroundColor Gray
    } else {
        Write-Host "✗ Export failed - file not found" -ForegroundColor Red
        exit 1
    }
}
catch {
    Write-Host "✗ Export failed: $_" -ForegroundColor Red
    exit 1
}

# Unpack Solution
Write-Host "`nUnpacking solution for source control..." -ForegroundColor Yellow

$unpackDir = Join-Path $solutionDir "unpacked"

if (Test-Path $unpackDir) {
    Write-Host "  Cleaning existing unpacked directory..." -ForegroundColor Gray
    Remove-Item -Path $unpackDir -Recurse -Force
}

try {
    pac solution unpack `
        --zipfile $exportPath `
        --folder $unpackDir
    
    if (Test-Path $unpackDir) {
        Write-Host "✓ Solution unpacked successfully" -ForegroundColor Green
        Write-Host "  Path: $unpackDir" -ForegroundColor Gray
    } else {
        Write-Host "✗ Unpack failed - directory not found" -ForegroundColor Red
        exit 1
    }
}
catch {
    Write-Host "✗ Unpack failed: $_" -ForegroundColor Red
    exit 1
}

# Validate unpacked structure
Write-Host "`nValidating unpacked structure..." -ForegroundColor Yellow

$requiredFiles = @(
    "solution.xml",
    "customizations.xml",
    "[Content_Types].xml"
)

$missingFiles = @()
foreach ($file in $requiredFiles) {
    $filePath = Join-Path $unpackDir $file
    if (Test-Path $filePath) {
        Write-Host "  ✓ $file" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $file - MISSING" -ForegroundColor Red
        $missingFiles += $file
    }
}

# Inventory components
Write-Host "`nInventorying solution components..." -ForegroundColor Yellow

$componentDirs = @(
    @{Name="Canvas Apps"; Path="CanvasApps"; Pattern="*.msapp"},
    @{Name="Flows"; Path="Workflows"; Pattern="*.json"},
    @{Name="Tables"; Path="Entities"; Pattern="*"},
    @{Name="Connection References"; Path="ConnectionReferences"; Pattern="*.xml"},
    @{Name="Environment Variables"; Path="EnvironmentVariableDefinitions"; Pattern="*.xml"},
    @{Name="Web Resources"; Path="WebResources"; Pattern="*"},
    @{Name="Security Roles"; Path="Roles"; Pattern="*.xml"}
)

$componentInventory = @()

foreach ($dir in $componentDirs) {
    $dirPath = Join-Path $unpackDir $dir.Path
    if (Test-Path $dirPath) {
        $items = Get-ChildItem -Path $dirPath -Filter $dir.Pattern -Recurse -ErrorAction SilentlyContinue
        $count = if ($items) { $items.Count } else { 0 }
        $componentInventory += [PSCustomObject]@{
            ComponentType = $dir.Name
            Count = $count
            Path = $dir.Path
        }
        Write-Host "  $($dir.Name): $count" -ForegroundColor Green
    } else {
        $componentInventory += [PSCustomObject]@{
            ComponentType = $dir.Name
            Count = 0
            Path = $dir.Path
        }
        Write-Host "  $($dir.Name): 0" -ForegroundColor Gray
    }
}

# Generate validation report
Write-Host "`nGenerating validation report..." -ForegroundColor Yellow

$validationReport = @"
# Solution Export and Unpack Validation Report
Generated: $(Get-Date)
Source Environment: $EnvironmentUrl
Solution: $SolutionName
Managed: $Managed

## Export Status
- Export Path: $exportPath
- Export Size: $([math]::Round((Get-Item $exportPath).Length / 1MB, 2)) MB
- Export Status: ✓ SUCCESS

## Unpack Status
- Unpack Directory: $unpackDir
- Unpack Status: ✓ SUCCESS

## Required Files Validation
$(foreach ($file in $requiredFiles) {
    $status = if ($missingFiles -contains $file) { "✗ MISSING" } else { "✓ FOUND" }
    "- $file : $status"
})

## Component Inventory
| Component Type | Count | Status |
|----------------|-------|--------|
$(foreach ($comp in $componentInventory) {
    $status = if ($comp.Count -gt 0) { "✓" } else { "⚠" }
    "| $($comp.ComponentType) | $($comp.Count) | $status |"
})

## File Structure
```
$solutionDir
├── $zipFileName (exported solution)
└── unpacked/
    ├── solution.xml
    ├── customizations.xml
    ├── [Content_Types].xml
    ├── CanvasApps/
    ├── Workflows/
    ├── Entities/
    ├── ConnectionReferences/
    ├── EnvironmentVariableDefinitions/
    ├── WebResources/
    └── Roles/
```

## Next Steps
1. Review unpacked files in: $unpackDir
2. Add to Git repository: git add solutions/
3. Create GitHub Actions workflows
4. Configure environment-specific values in config/
"@

$reportPath = Join-Path $solutionDir "Export_Validation_Report.md"
$validationReport | Out-File -FilePath $reportPath -Encoding utf8
Write-Host "✓ Validation report saved: $reportPath" -ForegroundColor Green

# Export component inventory
$inventoryPath = Join-Path $solutionDir "Component_Inventory.csv"
$componentInventory | Export-Csv -Path $inventoryPath -NoTypeInformation
Write-Host "✓ Component inventory saved: $inventoryPath" -ForegroundColor Green

# Summary
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "EXPORT AND UNPACK COMPLETE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Solution: $exportPath" -ForegroundColor Green
Write-Host "Unpacked: $unpackDir" -ForegroundColor Green
Write-Host "Report: $reportPath" -ForegroundColor Green

if ($missingFiles.Count -gt 0) {
    Write-Host "`n⚠ Warning: Missing required files: $($missingFiles -join ', ')" -ForegroundColor Yellow
}

Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Review the unpacked solution files" -ForegroundColor White
Write-Host "2. Add to Git: git add solutions/" -ForegroundColor White
Write-Host "3. Commit: git commit -m 'Add CWF solution'" -ForegroundColor White
Write-Host "4. Create GitHub Actions workflows" -ForegroundColor White
