# CWF-REPAIR-LOOKUPS.ps1
# Creates the 20 lookup relationships that failed due to non-unique NavigationPropertyName
# Usage: .\CWF-REPAIR-LOOKUPS.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"

param(
    [Parameter(Mandatory=$true)]
    [string]$EnvironmentUrl,
    [Parameter(Mandatory=$false)]
    [string]$AccessToken
)

#Requires -Version 5.1
$ErrorActionPreference = "Stop"

# AUTH
function Get-DataverseToken {
    param([string]$EnvUrl)
    if ($AccessToken) { return $AccessToken }
    $clientId = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $resource = "$($EnvUrl.TrimEnd('/'))/"
    Write-Host "  Requesting device code..." -ForegroundColor Yellow
    $dcr = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/common/oauth2/devicecode" `
        -Body @{ client_id = $clientId; resource = $resource } `
        -ContentType "application/x-www-form-urlencoded"
    Write-Host "  Go to: $($dcr.verification_url)" -ForegroundColor Yellow
    Write-Host "  Code:  $($dcr.user_code)" -ForegroundColor Green
    Write-Host "  Waiting..." -ForegroundColor Gray
    $tb = @{ grant_type = "urn:ietf:params:oauth:grant-type:device_code"; client_id = $clientId; code = $dcr.device_code }
    $interval = [Math]::Max([int]$dcr.interval, 5)
    $deadline = (Get-Date).AddSeconds([int]$dcr.expires_in)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tr = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/common/oauth2/token" -Body $tb -ContentType "application/x-www-form-urlencoded"
            Write-Host "  Authenticated!" -ForegroundColor Green
            return $tr.access_token
        } catch {
            $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($err.error -eq "authorization_pending") { continue }
            elseif ($err.error -eq "slow_down") { $interval += 5; continue }
            else { throw "Auth failed: $($err.error_description)" }
        }
    }
    throw "Timed out."
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Lookup Repair (20 relationships)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$apiBase = "$($EnvironmentUrl.TrimEnd('/'))/api/data/v9.2"
$token = Get-DataverseToken -EnvUrl $EnvironmentUrl
$headers = @{
    "Authorization" = "Bearer $token"
    "OData-MaxVersion" = "4.0"; "OData-Version" = "4.0"
    "Accept" = "application/json"
    "Content-Type" = "application/json; charset=utf-8"
}

# The 20 lookups that failed - with UNIQUE SchemaNames using source_column pattern
$lookups = @(
    # position.cwf_workroleid -> cwf_dcwfworkrole (collided with wrcmapping's)
    @{ Source="cwf_position"; Target="cwf_dcwfworkrole"; Column="cwf_workroleid"; Display="Work Role"; Schema="cwf_position_workrole" },

    # personnel.cwf_organizationid -> cwf_organization (collided with position's)
    @{ Source="cwf_personnel"; Target="cwf_organization"; Column="cwf_organizationid"; Display="Organization"; Schema="cwf_personnel_org" },

    # roledocumentreq.cwf_networkroleid -> cwf_networkrole (collided with roletrainingreq's)
    @{ Source="cwf_roledocumentreq"; Target="cwf_networkrole"; Column="cwf_networkroleid"; Display="Network Role"; Schema="cwf_roledocreq_networkrole" },

    # orgrequirementoverride.cwf_organizationid -> cwf_organization
    @{ Source="cwf_orgrequirementoverride"; Target="cwf_organization"; Column="cwf_organizationid"; Display="Organization"; Schema="cwf_orgoverride_org" },

    # orgrequirementoverride.cwf_networkroleid -> cwf_networkrole
    @{ Source="cwf_orgrequirementoverride"; Target="cwf_networkrole"; Column="cwf_networkroleid"; Display="Network Role"; Schema="cwf_orgoverride_networkrole" },

    # orgrequirementoverride.cwf_trainingdefinitionid -> cwf_trainingdefinition
    @{ Source="cwf_orgrequirementoverride"; Target="cwf_trainingdefinition"; Column="cwf_trainingdefinitionid"; Display="Training Definition"; Schema="cwf_orgoverride_trainingdef" },

    # training.cwf_trainingdefinitionid -> cwf_trainingdefinition (collided with roletrainingreq's)
    @{ Source="cwf_training"; Target="cwf_trainingdefinition"; Column="cwf_trainingdefinitionid"; Display="Training Definition"; Schema="cwf_training_trainingdef" },

    # qualification.cwf_personnelid -> cwf_personnel
    @{ Source="cwf_qualification"; Target="cwf_personnel"; Column="cwf_personnelid"; Display="Personnel"; Schema="cwf_qualification_personnel" },

    # qualification.cwf_workroleid -> cwf_dcwfworkrole
    @{ Source="cwf_qualification"; Target="cwf_dcwfworkrole"; Column="cwf_workroleid"; Display="Work Role"; Schema="cwf_qualification_workrole" },

    # certification.cwf_personnelid -> cwf_personnel
    @{ Source="cwf_certification"; Target="cwf_personnel"; Column="cwf_personnelid"; Display="Personnel"; Schema="cwf_certification_personnel" },

    # saar.cwf_personnelid -> cwf_personnel
    @{ Source="cwf_saar"; Target="cwf_personnel"; Column="cwf_personnelid"; Display="Personnel"; Schema="cwf_saar_personnel" },

    # saar.cwf_networkroleid -> cwf_networkrole
    @{ Source="cwf_saar"; Target="cwf_networkrole"; Column="cwf_networkroleid"; Display="Network Role"; Schema="cwf_saar_networkrole" },

    # appointmentorder.cwf_personnelid -> cwf_personnel
    @{ Source="cwf_appointmentorder"; Target="cwf_personnel"; Column="cwf_personnelid"; Display="Personnel"; Schema="cwf_apptorder_personnel" },

    # appointmentorder.cwf_networkroleid -> cwf_networkrole
    @{ Source="cwf_appointmentorder"; Target="cwf_networkrole"; Column="cwf_networkroleid"; Display="Network Role"; Schema="cwf_apptorder_networkrole" },

    # experienceeval.cwf_personnelid -> cwf_personnel
    @{ Source="cwf_experienceeval"; Target="cwf_personnel"; Column="cwf_personnelid"; Display="Personnel"; Schema="cwf_expeval_personnel" },

    # experienceeval.cwf_workroleid -> cwf_dcwfworkrole
    @{ Source="cwf_experienceeval"; Target="cwf_dcwfworkrole"; Column="cwf_workroleid"; Display="Work Role"; Schema="cwf_expeval_workrole" },

    # delegation.cwf_organizationid -> cwf_organization
    @{ Source="cwf_delegation"; Target="cwf_organization"; Column="cwf_organizationid"; Display="Organization"; Schema="cwf_delegation_org" },

    # compliancescore.cwf_personnelid -> cwf_personnel
    @{ Source="cwf_compliancescore"; Target="cwf_personnel"; Column="cwf_personnelid"; Display="Personnel"; Schema="cwf_score_personnel" },

    # compliancescore.cwf_networkroleid -> cwf_networkrole
    @{ Source="cwf_compliancescore"; Target="cwf_networkrole"; Column="cwf_networkroleid"; Display="Network Role"; Schema="cwf_score_networkrole" },

    # compliancescore.cwf_trainingdefinitionid -> cwf_trainingdefinition
    @{ Source="cwf_compliancescore"; Target="cwf_trainingdefinition"; Column="cwf_trainingdefinitionid"; Display="Training Definition"; Schema="cwf_score_trainingdef" }
)

$created = 0
$errors = 0

foreach ($lk in $lookups) {
    Write-Host "  $($lk.Source).$($lk.Column) -> $($lk.Target) [Schema: $($lk.Schema)]" -ForegroundColor Gray

    $body = @{
        "@odata.type" = "Microsoft.Dynamics.CRM.OneToManyRelationshipMetadata"
        SchemaName = $lk.Schema
        ReferencedEntity = $lk.Target
        ReferencingEntity = $lk.Source
        Lookup = @{
            "@odata.type" = "Microsoft.Dynamics.CRM.LookupAttributeMetadata"
            SchemaName = $lk.Column
            DisplayName = @{
                "@odata.type" = "Microsoft.Dynamics.CRM.Label"
                LocalizedLabels = @(@{
                    "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"
                    Label = $lk.Display
                    LanguageCode = 1033
                })
            }
            RequiredLevel = @{ Value = "None"; CanBeChanged = $true }
        }
        CascadeConfiguration = @{
            Assign = "NoCascade"; Delete = "RemoveLink"; Merge = "NoCascade"
            Reparent = "NoCascade"; Share = "NoCascade"; Unshare = "NoCascade"
        }
    } | ConvertTo-Json -Depth 20

    try {
        Invoke-RestMethod -Method POST -Uri "$apiBase/RelationshipDefinitions" -Headers $headers -Body $body | Out-Null
        Write-Host "    Created" -ForegroundColor Green
        $created++
    }
    catch {
        $errMsg = $_.ErrorDetails.Message
        try {
            $parsed = $errMsg | ConvertFrom-Json
            Write-Host "    Error: $($parsed.error.message)" -ForegroundColor Red
        } catch {
            Write-Host "    Error: $errMsg" -ForegroundColor Red
        }
        $errors++
    }
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "REPAIR SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total: $($lookups.Count)" -ForegroundColor White
Write-Host "Created: $created" -ForegroundColor Green
Write-Host "Errors: $errors" -ForegroundColor $(if ($errors -gt 0) { "Red" } else { "Green" })

if ($errors -eq 0) {
    Write-Host "`nALL LOOKUPS REPAIRED! Total relationships: 35 (15 original + 20 repaired)" -ForegroundColor Green
}
