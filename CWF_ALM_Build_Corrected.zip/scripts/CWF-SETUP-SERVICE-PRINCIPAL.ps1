# CWF-SETUP-SERVICE-PRINCIPAL.ps1
# Creates an Azure AD App Registration and Service Principal for CWF ALM CI/CD
# Usage: .\CWF-SETUP-SERVICE-PRINCIPAL.ps1 -EnvironmentName "DEV" -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com"
#
# PREREQUISITES:
#   - Azure CLI (az) installed and authenticated with sufficient privileges
#   - Power Platform CLI (pac) installed
#   - Azure AD Global Admin or Application Administrator role

param(
    [Parameter(Mandatory=$true, HelpMessage="Environment name (DEV, TEST, PROD)")]
    [ValidateSet("DEV", "TEST", "PROD")]
    [string]$EnvironmentName,

    [Parameter(Mandatory=$true, HelpMessage="Dataverse environment URL")]
    [string]$EnvironmentUrl,

    [Parameter(Mandatory=$false)]
    [string]$AppName = "CWF-PowerPlatform-Deployment"
)

#Requires -Version 5.1

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Service Principal Setup for CWF ALM" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $EnvironmentName" -ForegroundColor White
Write-Host "URL: $EnvironmentUrl" -ForegroundColor White
Write-Host ""

# ============================================================
# Step 1: Verify Azure CLI authentication
# ============================================================
Write-Host "Step 1: Verifying Azure CLI authentication..." -ForegroundColor Yellow

try {
    $account = az account show --output json 2>$null | ConvertFrom-Json
    if (!$account) { throw "Not authenticated" }
    Write-Host "  Authenticated as: $($account.user.name)" -ForegroundColor Green
    Write-Host "  Tenant: $($account.tenantId)" -ForegroundColor Gray
    $tenantId = $account.tenantId
}
catch {
    Write-Host "  Not authenticated to Azure CLI. Run 'az login' first." -ForegroundColor Red
    exit 1
}

# ============================================================
# Step 2: Create Azure AD App Registration
# ============================================================
Write-Host "`nStep 2: Creating Azure AD App Registration..." -ForegroundColor Yellow

$existingApp = az ad app list --display-name $AppName --output json 2>$null | ConvertFrom-Json

if ($existingApp -and $existingApp.Count -gt 0) {
    Write-Host "  App Registration '$AppName' already exists." -ForegroundColor Yellow
    $app = $existingApp[0]
    $appId = $app.appId
    $objectId = $app.id
    Write-Host "  App ID: $appId" -ForegroundColor Gray
} else {
    $app = az ad app create `
        --display-name $AppName `
        --sign-in-audience AzureADMyOrg `
        --output json | ConvertFrom-Json

    $appId = $app.appId
    $objectId = $app.id
    Write-Host "  App Registration Created" -ForegroundColor Green
    Write-Host "  App ID: $appId" -ForegroundColor Gray
    Write-Host "  Object ID: $objectId" -ForegroundColor Gray
}

# ============================================================
# Step 3: Create Service Principal (if not exists)
# ============================================================
Write-Host "`nStep 3: Creating Service Principal..." -ForegroundColor Yellow

$existingSp = az ad sp show --id $appId --output json 2>$null | ConvertFrom-Json

if ($existingSp) {
    Write-Host "  Service Principal already exists." -ForegroundColor Yellow
    $spObjectId = $existingSp.id
} else {
    $sp = az ad sp create --id $appId --output json | ConvertFrom-Json
    $spObjectId = $sp.id
    Write-Host "  Service Principal Created" -ForegroundColor Green
}
Write-Host "  SP Object ID: $spObjectId" -ForegroundColor Gray

# ============================================================
# Step 4: Create Client Secret
# ============================================================
Write-Host "`nStep 4: Creating Client Secret..." -ForegroundColor Yellow

$secret = az ad app credential reset `
    --id $appId `
    --display-name "GitHub-Actions-$EnvironmentName" `
    --years 2 `
    --output json | ConvertFrom-Json

$clientSecret = $secret.password

Write-Host "  Client Secret Created" -ForegroundColor Green
Write-Host ""
Write-Host "  ==============================================" -ForegroundColor Red
Write-Host "  SAVE THIS SECRET NOW - IT WILL NOT BE SHOWN AGAIN" -ForegroundColor Red
Write-Host "  Secret: $clientSecret" -ForegroundColor Yellow
Write-Host "  ==============================================" -ForegroundColor Red

# ============================================================
# Step 5: Add to Power Platform as Application User
# ============================================================
Write-Host "`nStep 5: Adding Application User to Power Platform..." -ForegroundColor Yellow

Write-Host "  Registering application user in Dataverse..." -ForegroundColor Gray

try {
    pac admin assign-user `
        --environment $EnvironmentUrl `
        --user $appId `
        --role "System Administrator" `
        --application-user

    Write-Host "  Application user assigned with System Administrator role" -ForegroundColor Green
}
catch {
    Write-Host "  Could not auto-assign. Manual steps required:" -ForegroundColor Yellow
    Write-Host "    1. Go to Power Platform Admin Center > Environments > $EnvironmentName" -ForegroundColor White
    Write-Host "    2. Settings > Users + Permissions > Application Users" -ForegroundColor White
    Write-Host "    3. New App User > Add the App ID: $appId" -ForegroundColor White
    Write-Host "    4. Assign 'System Administrator' security role" -ForegroundColor White
}

# ============================================================
# Step 6: Validate authentication
# ============================================================
Write-Host "`nStep 6: Validating Service Principal authentication..." -ForegroundColor Yellow

try {
    pac auth create `
        --name "CWF-$EnvironmentName" `
        --applicationId $appId `
        --clientSecret $clientSecret `
        --tenant $tenantId `
        --environment $EnvironmentUrl

    # Verify connectivity
    $orgResult = pac org who 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  Authentication validated successfully!" -ForegroundColor Green
    } else {
        Write-Host "  Authentication profile created but org verification returned: $orgResult" -ForegroundColor Yellow
    }
}
catch {
    Write-Host "  Auth validation failed: $_" -ForegroundColor Yellow
    Write-Host "  This may be a timing issue - try again in 60 seconds" -ForegroundColor Gray
}

# ============================================================
# Step 7: Generate GitHub Secrets
# ============================================================
Write-Host "`nStep 7: Generating GitHub Secrets reference..." -ForegroundColor Yellow

$secretsRef = @"
# =============================================
# GitHub Repository Secrets to Configure
# Settings > Secrets and variables > Actions
# =============================================

POWERPLATFORM_APPID = $appId
POWERPLATFORM_CLIENTSECRET = $clientSecret
POWERPLATFORM_TENANTID = $tenantId
$($EnvironmentName.ToUpper())_ENVIRONMENT_URL = $EnvironmentUrl

# =============================================
# For additional environments, add:
# TEST_ENVIRONMENT_URL = https://your-test-env.crm.dynamics.com
# PROD_ENVIRONMENT_URL = https://your-prod-env.crm.dynamics.com
# SOURCE_ENVIRONMENT_URL = (if different from dev)
# SLACK_WEBHOOK_URL = (optional, for deployment notifications)
# =============================================
"@

$secretsFile = "github-secrets-$EnvironmentName.txt"
$secretsRef | Out-File -FilePath $secretsFile -Encoding utf8
Write-Host "  Secrets reference saved to: $secretsFile" -ForegroundColor Green

# ============================================================
# SUMMARY
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SETUP COMPLETE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "App Registration: $AppName" -ForegroundColor White
Write-Host "App (Client) ID: $appId" -ForegroundColor White
Write-Host "Tenant ID: $tenantId" -ForegroundColor White
Write-Host "Environment: $EnvironmentName ($EnvironmentUrl)" -ForegroundColor White
Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor Yellow
Write-Host "  1. Copy the client secret from $secretsFile" -ForegroundColor White
Write-Host "  2. Add all secrets to GitHub repository (Settings > Secrets > Actions)" -ForegroundColor White
Write-Host "  3. Configure GitHub environment protection rules for Production" -ForegroundColor White
Write-Host "  4. Run a test PR to validate the pipeline" -ForegroundColor White
Write-Host ""
Write-Host "  DELETE $secretsFile after adding secrets to GitHub!" -ForegroundColor Red

# Output structured result
$result = @{
    appId          = $appId
    objectId       = $objectId
    spObjectId     = $spObjectId
    tenantId       = $tenantId
    environment    = $EnvironmentName
    environmentUrl = $EnvironmentUrl
} | ConvertTo-Json

$result | Out-File -FilePath "service-principal-$EnvironmentName.json" -Encoding utf8
Write-Host "`nConfiguration saved to: service-principal-$EnvironmentName.json" -ForegroundColor Cyan
