# CWF-VALIDATE-DEPLOYMENT.ps1
# Comprehensive post-deployment validation for CWF solution using Dataverse Web API
# Usage: .\CWF-VALIDATE-DEPLOYMENT.ps1 -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com" -EnvironmentName "DEV"
#
# CORRECTED: All queries use Dataverse Web API (Invoke-RestMethod) instead of
# non-existent pac CLI subcommands. See README.md for the Web API pattern reference.

param(
    [Parameter(Mandatory=$true, HelpMessage="Dataverse environment URL")]
    [string]$EnvironmentUrl,

    [Parameter(Mandatory=$true, HelpMessage="Environment name (DEV, TEST, PROD)")]
    [ValidateSet("DEV", "TEST", "PROD")]
    [string]$EnvironmentName,

    [Parameter(Mandatory=$false)]
    [string]$ConfigPath = "config",

    [Parameter(Mandatory=$false)]
    [switch]$Detailed,

    [Parameter(Mandatory=$false, HelpMessage="OAuth access token. If omitted, script uses pac auth.")]
    [string]$AccessToken
)

#Requires -Version 5.1

$ErrorActionPreference = "Continue"

# ============================================================
# HELPER: Get token via device code flow (PS 5.1 compatible)
# ============================================================
function Get-DataverseToken {
    param([string]$EnvUrl)
    if ($AccessToken) { return $AccessToken }

    $clientId = "51f81489-12ee-4a9e-aaae-a2591f45987d"
    $resource = "$($EnvUrl.TrimEnd('/'))/"

    Write-Host "  Requesting device code for authentication..." -ForegroundColor Yellow
    $deviceCodeResponse = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/common/oauth2/devicecode" `
        -Body @{ client_id = $clientId; resource = $resource } `
        -ContentType "application/x-www-form-urlencoded"

    Write-Host ""
    Write-Host "  To sign in, go to: $($deviceCodeResponse.verification_url)" -ForegroundColor Yellow
    Write-Host "  Enter the code:    $($deviceCodeResponse.user_code)" -ForegroundColor Green
    Write-Host "  Waiting for authentication..." -ForegroundColor Gray

    $tokenBody = @{
        grant_type = "urn:ietf:params:oauth:grant-type:device_code"
        client_id  = $clientId
        code       = $deviceCodeResponse.device_code
    }
    $interval = [Math]::Max([int]$deviceCodeResponse.interval, 5)
    $deadline = (Get-Date).AddSeconds([int]$deviceCodeResponse.expires_in)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tokenResponse = Invoke-RestMethod -Method POST `
                -Uri "https://login.microsoftonline.com/common/oauth2/token" `
                -Body $tokenBody -ContentType "application/x-www-form-urlencoded"
            Write-Host "  Authenticated successfully!" -ForegroundColor Green
            return $tokenResponse.access_token
        }
        catch {
            $err = $_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($err.error -eq "authorization_pending") { continue }
            elseif ($err.error -eq "slow_down") { $interval += 5; continue }
            else { throw "Auth failed: $($err.error_description)" }
        }
    }
    throw "Authentication timed out."
}

# ============================================================
# HELPER: Invoke Dataverse Web API
# ============================================================
function Invoke-DataverseApi {
    param(
        [string]$Uri,
        [string]$Token
    )
    $headers = @{
        "Authorization"    = "Bearer $Token"
        "OData-MaxVersion" = "4.0"
        "OData-Version"    = "4.0"
        "Accept"           = "application/json"
        "Prefer"           = "odata.include-annotations=*"
    }
    return Invoke-RestMethod -Method GET -Uri $Uri -Headers $headers
}

# ============================================================
# MAIN
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "CWF Deployment Validation" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $EnvironmentName" -ForegroundColor White
Write-Host "URL: $EnvironmentUrl" -ForegroundColor White
Write-Host "Started: $(Get-Date)" -ForegroundColor Gray
Write-Host ""

$apiBase = "$($EnvironmentUrl.TrimEnd('/'))/api/data/v9.2"
$token = Get-DataverseToken -EnvUrl $EnvironmentUrl

$validationResults = @{
    TotalChecks = 0
    Passed = 0
    Failed = 0
    Warnings = 0
    Details = @()
}

function Add-ValidationResult {
    param(
        [string]$Category,
        [string]$Check,
        [string]$Status,
        [string]$Details = "",
        [switch]$IsWarning
    )

    $validationResults.TotalChecks++

    if ($Status -eq "PASS") {
        $validationResults.Passed++
        $color = "Green"
    } elseif ($IsWarning) {
        $validationResults.Warnings++
        $color = "Yellow"
        $Status = "WARNING"
    } else {
        $validationResults.Failed++
        $color = "Red"
    }

    $validationResults.Details += [PSCustomObject]@{
        Category = $Category
        Check = $Check
        Status = $Status
        Details = $Details
    }

    if ($Detailed -or $Status -ne "PASS") {
        Write-Host "[$Status] $Category - $Check" -ForegroundColor $color
        if ($Details) {
            Write-Host "  $Details" -ForegroundColor Gray
        }
    }
}

# ============================================================
# CHECK 1: Solution Installed
# ============================================================
Write-Host "Checking solution..." -ForegroundColor Yellow

try {
    $solQuery = "$apiBase/solutions?`$select=friendlyname,version,uniquename&`$filter=uniquename eq 'DoD8140CWFCompliance'"
    $solResult = Invoke-DataverseApi -Uri $solQuery -Token $token

    if ($solResult.value.Count -gt 0) {
        $sol = $solResult.value[0]
        Add-ValidationResult -Category "Solution" -Check "CWF Solution" -Status "PASS" -Details "v$($sol.version) - $($sol.friendlyname)"
    } else {
        Add-ValidationResult -Category "Solution" -Check "CWF Solution" -Status "FAIL" -Details "Solution 'DoD8140CWFCompliance' not found"
    }
}
catch {
    Add-ValidationResult -Category "Solution" -Check "CWF Solution" -Status "FAIL" -Details $_.Exception.Message
}

# ============================================================
# CHECK 2: Environment Variables
# ============================================================
Write-Host "`nChecking Environment Variables..." -ForegroundColor Yellow

$envConfigPath = Join-Path $ConfigPath "$($EnvironmentName.ToLower())-environment.json"

if (Test-Path $envConfigPath) {
    $envConfig = Get-Content $envConfigPath | ConvertFrom-Json

    foreach ($var in $envConfig.environmentVariables) {
        try {
            $evQuery = "$apiBase/environmentvariabledefinitions?`$select=schemaname,displayname&`$filter=schemaname eq '$($var.name)'"
            $evResult = Invoke-DataverseApi -Uri $evQuery -Token $token

            if ($evResult.value.Count -gt 0) {
                Add-ValidationResult -Category "Environment Variables" -Check $var.name -Status "PASS"
            } else {
                Add-ValidationResult -Category "Environment Variables" -Check $var.name -Status "FAIL" -Details "Not found in Dataverse"
            }
        }
        catch {
            Add-ValidationResult -Category "Environment Variables" -Check $var.name -Status "FAIL" -Details $_.Exception.Message
        }
    }
} else {
    Add-ValidationResult -Category "Environment Variables" -Check "Config File" -Status "FAIL" -Details "Config not found: $envConfigPath"
}

# ============================================================
# CHECK 3: Connection References
# ============================================================
Write-Host "`nChecking Connection References..." -ForegroundColor Yellow

$connRefPath = "connection-references/connection-references.json"

if (Test-Path $connRefPath) {
    $connRefs = Get-Content $connRefPath | ConvertFrom-Json

    # Query all connection references in the environment
    try {
        $crQuery = "$apiBase/connectionreferences?`$select=connectionreferencelogicalname,connectionreferencedisplayname,connectorid,statecode"
        $crResult = Invoke-DataverseApi -Uri $crQuery -Token $token
        $existingConnRefs = @{}
        foreach ($cr in $crResult.value) {
            $existingConnRefs[$cr.connectionreferencelogicalname] = $cr
        }

        foreach ($conn in $connRefs.connectionReferences) {
            # Check by looking for any connection ref that matches the connector type
            $found = $crResult.value | Where-Object { $_.connectorid -like "*$($conn.type)*" }
            if ($found) {
                Add-ValidationResult -Category "Connection References" -Check $conn.name -Status "PASS" -Details "Type: $($conn.type)"
            } else {
                $isOptional = $conn.note -and $conn.note -like "*Optional*"
                if ($isOptional) {
                    Add-ValidationResult -Category "Connection References" -Check $conn.name -Status "PASS" -Details "Optional - not configured" -IsWarning
                } else {
                    Add-ValidationResult -Category "Connection References" -Check $conn.name -Status "FAIL" -Details "No connection reference found for type: $($conn.type)"
                }
            }
        }
    }
    catch {
        Add-ValidationResult -Category "Connection References" -Check "Query" -Status "FAIL" -Details $_.Exception.Message
    }
} else {
    Add-ValidationResult -Category "Connection References" -Check "Definition File" -Status "FAIL" -Details "Not found: $connRefPath"
}

# ============================================================
# CHECK 4: Flow Status (using Dataverse workflow entity)
# ============================================================
Write-Host "`nChecking Flow Status..." -ForegroundColor Yellow

try {
    # Query Power Automate flows via the process (workflow) table
    # category 5 = Modern Flow (Cloud Flow)
    $flowQuery = "$apiBase/workflows?`$select=name,statecode,statuscode,category&`$filter=category eq 5 and startswith(name,'CWF')"
    $flowResult = Invoke-DataverseApi -Uri $flowQuery -Token $token

    if ($flowResult.value.Count -gt 0) {
        Add-ValidationResult -Category "Flows" -Check "Total Flows" -Status "PASS" -Details "Found $($flowResult.value.Count) CWF flows"

        $activeFlows = $flowResult.value | Where-Object { $_.statecode -eq 1 }
        $inactiveFlows = $flowResult.value | Where-Object { $_.statecode -ne 1 }

        Add-ValidationResult -Category "Flows" -Check "Active Flows" -Status "PASS" -Details "$($activeFlows.Count) of $($flowResult.value.Count) active"

        foreach ($flow in $inactiveFlows) {
            Add-ValidationResult -Category "Flows" -Check $flow.name -Status "FAIL" -Details "State: $($flow.statecode) / Status: $($flow.statuscode) - Needs activation"
        }
    } else {
        Add-ValidationResult -Category "Flows" -Check "Flow List" -Status "FAIL" -Details "No CWF flows found (query: category=5, name starts with 'CWF')"
    }
}
catch {
    Add-ValidationResult -Category "Flows" -Check "Flow Query" -Status "FAIL" -Details $_.Exception.Message
}

# ============================================================
# CHECK 5: Dataverse Tables (using EntityDefinitions metadata)
# ============================================================
Write-Host "`nChecking Dataverse Tables..." -ForegroundColor Yellow

$requiredTables = @(
    "cwf_personnel",
    "cwf_training",
    "cwf_saar",
    "cwf_compliancescore",
    "cwf_networkrole",
    "cwf_trainingdefinition",
    "cwf_roletrainingreq",
    "cwf_orgrequirementoverride",
    "cwf_roledocumentreq",
    "cwf_qualification",
    "cwf_certification",
    "cwf_appointmentorder",
    "cwf_requirementsconfig",
    "cwf_auditlog"
)

try {
    # Query entity definitions for tables with cwf_ prefix
    $entityQuery = "$apiBase/EntityDefinitions?`$select=LogicalName,DisplayName,EntitySetName&`$filter=startswith(LogicalName,'cwf_')"
    $entityResult = Invoke-DataverseApi -Uri $entityQuery -Token $token

    $foundTables = @{}
    foreach ($entity in $entityResult.value) {
        $foundTables[$entity.LogicalName] = $true
    }

    foreach ($table in $requiredTables) {
        if ($foundTables.ContainsKey($table)) {
            Add-ValidationResult -Category "Tables" -Check $table -Status "PASS"
        } else {
            Add-ValidationResult -Category "Tables" -Check $table -Status "FAIL" -Details "Table not found"
        }
    }

    # Report any extra tables found
    $extraTables = $foundTables.Keys | Where-Object { $_ -notin $requiredTables }
    if ($extraTables.Count -gt 0) {
        Add-ValidationResult -Category "Tables" -Check "Additional Tables" -Status "PASS" -Details "Found $($extraTables.Count) additional cwf_ tables: $($extraTables -join ', ')" -IsWarning
    }
}
catch {
    Add-ValidationResult -Category "Tables" -Check "Entity Query" -Status "FAIL" -Details $_.Exception.Message
}

# ============================================================
# CHECK 6: Security Roles
# ============================================================
Write-Host "`nChecking Security Roles..." -ForegroundColor Yellow

$requiredRoles = @(
    "CWF System Admin",
    "CWF ISSM",
    "CWF ISSO",
    "CWF Supervisor",
    "CWF Member",
    "CWF Read Only",
    "CWF Import User",
    "CWF Auditor"
)

try {
    $roleQuery = "$apiBase/roles?`$select=name&`$filter=startswith(name,'CWF')"
    $roleResult = Invoke-DataverseApi -Uri $roleQuery -Token $token

    $foundRoles = $roleResult.value | ForEach-Object { $_.name }

    foreach ($role in $requiredRoles) {
        if ($foundRoles -contains $role) {
            Add-ValidationResult -Category "Security Roles" -Check $role -Status "PASS"
        } else {
            Add-ValidationResult -Category "Security Roles" -Check $role -Status "FAIL" -Details "Role not found"
        }
    }
}
catch {
    Add-ValidationResult -Category "Security Roles" -Check "Role Query" -Status "FAIL" -Details $_.Exception.Message
}

# ============================================================
# CHECK 7: Dataverse Connectivity (basic smoke test)
# ============================================================
Write-Host "`nRunning smoke test..." -ForegroundColor Yellow

try {
    $whoQuery = "$apiBase/WhoAmI"
    $whoResult = Invoke-DataverseApi -Uri $whoQuery -Token $token
    Add-ValidationResult -Category "Connectivity" -Check "WhoAmI" -Status "PASS" -Details "UserId: $($whoResult.UserId)"
}
catch {
    Add-ValidationResult -Category "Connectivity" -Check "WhoAmI" -Status "FAIL" -Details $_.Exception.Message
}

# ============================================================
# SUMMARY
# ============================================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "VALIDATION SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Checks: $($validationResults.TotalChecks)" -ForegroundColor White
Write-Host "Passed: $($validationResults.Passed)" -ForegroundColor Green
Write-Host "Failed: $($validationResults.Failed)" -ForegroundColor $(if ($validationResults.Failed -gt 0) { "Red" } else { "Green" })
Write-Host "Warnings: $($validationResults.Warnings)" -ForegroundColor Yellow

$passRate = if ($validationResults.TotalChecks -gt 0) { [math]::Round(($validationResults.Passed / $validationResults.TotalChecks) * 100, 1) } else { 0 }
Write-Host "Pass Rate: $passRate%" -ForegroundColor White

# Export detailed results
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outputFile = "Validation_Results_${EnvironmentName}_${timestamp}.csv"
$validationResults.Details | Export-Csv -Path $outputFile -NoTypeInformation
Write-Host "`nDetailed results exported to: $outputFile" -ForegroundColor Cyan

# Generate markdown report
$report = @"
# CWF Deployment Validation Report

**Environment**: $EnvironmentName
**URL**: $EnvironmentUrl
**Date**: $(Get-Date)

## Summary

| Metric | Value |
|--------|-------|
| Total Checks | $($validationResults.TotalChecks) |
| Passed | $($validationResults.Passed) |
| Failed | $($validationResults.Failed) |
| Warnings | $($validationResults.Warnings) |
| Pass Rate | $passRate% |

## Detailed Results

| Category | Check | Status | Details |
|----------|-------|--------|---------|
$(foreach ($detail in $validationResults.Details) {
    "| $($detail.Category) | $($detail.Check) | $($detail.Status) | $($detail.Details) |"
})

"@

$reportFile = "Validation_Report_${EnvironmentName}_${timestamp}.md"
$report | Out-File -FilePath $reportFile -Encoding utf8
Write-Host "Report saved to: $reportFile" -ForegroundColor Cyan

# Exit code
if ($validationResults.Failed -eq 0) {
    Write-Host "`nVALIDATION PASSED" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`nVALIDATION FAILED - $($validationResults.Failed) checks failed" -ForegroundColor Red
    exit 1
}
