# Solution Directory

This directory is populated when you run the solution export script:

```powershell
.\scripts\CWF-EXPORT-SOLUTION.ps1 `
  -EnvironmentUrl "https://orge0291f5f.crm.dynamics.com" `
  -SolutionName "DoD8140CWFCompliance"
```

After export, this directory will contain:

```
DoD8140CWFCompliance/
├── DoD8140CWFCompliance.zip    # Packed solution file
└── unpacked/                    # Source-controlled solution files
    ├── solution.xml
    ├── customizations.xml
    ├── [Content_Types].xml
    ├── CanvasApps/
    ├── Workflows/
    ├── Entities/
    ├── ConnectionReferences/
    └── EnvironmentVariableDefinitions/
```
