<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 1: Create Azure AD Security Groups
.DESCRIPTION
    Creates all Azure AD security groups for the CWF Centralized HQ-Admin Model:
    - HQ Admin groups (premium licensed)
    - Installation G-6 groups (SP elevated)  
    - Directorate consumer groups (SP standard)
    - Nested roll-up groups
.NOTES
    Requires: AzureAD or Microsoft.Graph PowerShell module
    Run as: Global Admin or Groups Administrator
    Environment: GCC / GCC High
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [switch]$WhatIf,
    [switch]$UseGraphAPI  # Use Microsoft.Graph instead of AzureAD module
)

$ErrorActionPreference = "Stop"

# ── Load Configuration ──
Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - Azure AD Group Provisioning" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$prefix = $config.AzureAD.GroupPrefix
$mscName = $config.MSC.Name

Write-Host "MSC: $mscName" -ForegroundColor Yellow
Write-Host "Group Prefix: $prefix" -ForegroundColor Yellow
Write-Host "Installations: $($config.Installations.Count)" -ForegroundColor Yellow
Write-Host ""

# ── Connect to Azure AD ──
if ($UseGraphAPI) {
    Write-Host "Connecting via Microsoft Graph..." -ForegroundColor Gray
    Connect-MgGraph -Scopes "Group.ReadWrite.All", "GroupMember.ReadWrite.All"
} else {
    Write-Host "Connecting via AzureAD module..." -ForegroundColor Gray
    Connect-AzureAD
}

# ── Helper Functions ──
function New-CWFGroup {
    param(
        [string]$Name,
        [string]$Description,
        [string]$Category = "HQ"
    )
    
    Write-Host "  Creating: $Name" -ForegroundColor White -NoNewline
    Write-Host " ($Description)" -ForegroundColor Gray
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would create group" -ForegroundColor DarkYellow
        return @{ DisplayName = $Name; ObjectId = "whatif-$Name" }
    }
    
    # Check if group already exists
    if ($UseGraphAPI) {
        $existing = Get-MgGroup -Filter "displayName eq '$Name'" -ErrorAction SilentlyContinue
    } else {
        $existing = Get-AzureADGroup -Filter "displayName eq '$Name'" -ErrorAction SilentlyContinue
    }
    
    if ($existing) {
        Write-Host "    [EXISTS] Group already exists - skipping" -ForegroundColor DarkYellow
        return $existing
    }
    
    if ($UseGraphAPI) {
        $group = New-MgGroup -DisplayName $Name `
            -Description $Description `
            -MailEnabled:$false `
            -MailNickname ($Name -replace '[^a-zA-Z0-9]', '') `
            -SecurityEnabled:$true `
            -GroupTypes @()
    } else {
        $group = New-AzureADGroup -DisplayName $Name `
            -Description $Description `
            -MailEnabled $false `
            -MailNickname ($Name -replace '[^a-zA-Z0-9]', '') `
            -SecurityEnabled $true
    }
    
    Write-Host "    [CREATED] $($group.Id)" -ForegroundColor Green
    return $group
}

function Add-CWFGroupNesting {
    param(
        [string]$ParentGroupName,
        [string]$ChildGroupName
    )
    
    Write-Host "  Nesting: $ChildGroupName --> $ParentGroupName" -ForegroundColor Gray
    
    if ($WhatIf) {
        Write-Host "    [WhatIf] Would add nesting" -ForegroundColor DarkYellow
        return
    }
    
    if ($UseGraphAPI) {
        $parent = Get-MgGroup -Filter "displayName eq '$ParentGroupName'"
        $child = Get-MgGroup -Filter "displayName eq '$ChildGroupName'"
        if ($parent -and $child) {
            try {
                New-MgGroupMember -GroupId $parent.Id -DirectoryObjectId $child.Id -ErrorAction Stop
                Write-Host "    [NESTED]" -ForegroundColor Green
            } catch {
                if ($_.Exception.Message -match "already exist") {
                    Write-Host "    [ALREADY NESTED]" -ForegroundColor DarkYellow
                } else { throw }
            }
        }
    } else {
        $parent = Get-AzureADGroup -Filter "displayName eq '$ParentGroupName'"
        $child = Get-AzureADGroup -Filter "displayName eq '$ChildGroupName'"
        if ($parent -and $child) {
            try {
                Add-AzureADGroupMember -ObjectId $parent.ObjectId -RefObjectId $child.ObjectId -ErrorAction Stop
                Write-Host "    [NESTED]" -ForegroundColor Green
            } catch {
                if ($_.Exception.Message -match "already exist") {
                    Write-Host "    [ALREADY NESTED]" -ForegroundColor DarkYellow
                } else { throw }
            }
        }
    }
}

# ── Track all created groups ──
$allGroups = @{}
$installG6Groups = @()

# ═══════════════════════════════════════
# PHASE 1: HQ Admin Groups (Premium)
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 1: HQ Admin Groups (Premium)     │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

foreach ($role in @("Admin", "ISSM", "Analyst", "Auditor", "ServiceAcct")) {
    $grpConfig = $config.AzureAD.HQGroups.$role
    $group = New-CWFGroup -Name $grpConfig.Name -Description $grpConfig.Description -Category "HQ"
    $allGroups[$grpConfig.Name] = $group
}

# Create nested HQALL group
$hqAllConfig = $config.AzureAD.HQGroups.AllHQ
$hqAllGroup = New-CWFGroup -Name $hqAllConfig.Name -Description $hqAllConfig.Description -Category "HQ"
$allGroups[$hqAllConfig.Name] = $hqAllGroup

# Nest HQ groups into HQALL
Write-Host "`n  Configuring HQALL nesting..." -ForegroundColor Yellow
foreach ($memberName in $hqAllConfig.NestedMembers) {
    Add-CWFGroupNesting -ParentGroupName $hqAllConfig.Name -ChildGroupName $memberName
}

# ═══════════════════════════════════════
# PHASE 2: Installation G-6 Groups
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 2: Installation G-6 Groups       │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

foreach ($install in $config.Installations) {
    $g6GroupName = "$prefix-$($install.Code)-G6"
    $g6Desc = "$($install.Name) G-6 Staff - SP Elevated (Full Control at installation)"
    
    $group = New-CWFGroup -Name $g6GroupName -Description $g6Desc -Category "InstallG6"
    $allGroups[$g6GroupName] = $group
    $installG6Groups += $g6GroupName
}

# Create nested ALLINSTG6 group
$allInstG6Config = $config.AzureAD.NestedAllInstG6
$allInstG6Group = New-CWFGroup -Name $allInstG6Config.Name -Description $allInstG6Config.Description -Category "Nested"
$allGroups[$allInstG6Config.Name] = $allInstG6Group

# Nest all install G-6 groups into ALLINSTG6
Write-Host "`n  Configuring ALLINSTG6 nesting..." -ForegroundColor Yellow
foreach ($g6GroupName in $installG6Groups) {
    Add-CWFGroupNesting -ParentGroupName $allInstG6Config.Name -ChildGroupName $g6GroupName
}

# ═══════════════════════════════════════
# PHASE 3: Directorate Consumer Groups
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 3: Directorate Consumer Groups   │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

$dirRoles = $config.AzureAD.DirectorateRoles  # ["Coord", "Supv", "Personnel"]
$totalDirGroups = 0

foreach ($install in $config.Installations) {
    Write-Host "`n  Installation: $($install.Name) ($($install.Code))" -ForegroundColor Yellow
    
    foreach ($dir in $install.Directorates) {
        # Skip creating consumer groups for G-6 directorates that are HQ Admin or Install G-6
        # They still get groups, but they're named differently and have fewer sub-roles
        
        $dirPrefix = "$prefix-$($install.Code)-$($dir.Code)"
        
        if ($dir.IsHQAdmin -eq $true) {
            # HQ Admin directorate - personnel here ARE the HQ team
            # They use HQ groups primarily, but need a personnel group for SP site access
            $group = New-CWFGroup -Name "$dirPrefix-Staff" `
                -Description "$($dir.Name) staff - HQ Admin team members" -Category "Dir"
            $allGroups["$dirPrefix-Staff"] = $group
            $totalDirGroups++
        }
        elseif ($dir.IsInstallG6 -eq $true) {
            # Installation G-6 - already has an install G-6 group
            # Add a personnel group for non-lead G-6 staff who need basic SP access
            $group = New-CWFGroup -Name "$dirPrefix-Staff" `
                -Description "$($dir.Name) staff - Installation G-6 team" -Category "Dir"
            $allGroups["$dirPrefix-Staff"] = $group
            $totalDirGroups++
        }
        else {
            # Standard directorate consumer - gets Coord, Supv, Personnel groups
            foreach ($role in $dirRoles) {
                $roleName = "$dirPrefix-$role"
                $roleDesc = switch ($role) {
                    "Coord"     { "$($dir.Name) CWF Coordinator - SP Edit on own dir" }
                    "Supv"      { "$($dir.Name) Supervisors - SP Edit on own dir" }
                    "Personnel" { "$($dir.Name) Self-Service Personnel - SP Contribute" }
                }
                
                $group = New-CWFGroup -Name $roleName -Description $roleDesc -Category "Dir"
                $allGroups[$roleName] = $group
                $totalDirGroups++
            }
        }
    }
}

# ═══════════════════════════════════════
# PHASE 4: SAAR Approver Groups (per installation)
# ═══════════════════════════════════════
Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  PHASE 4: SAAR Approver Groups          │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan

foreach ($install in $config.Installations) {
    foreach ($dir in $install.Directorates) {
        if (-not $dir.IsHQAdmin -and -not $dir.IsInstallG6) {
            $saarGroupName = "$prefix-$($install.Code)-$($dir.Code)-SAARAprv"
            $saarDesc = "$($dir.Name) SAAR Approvers - Custom SP permission on SAAR list"
            $group = New-CWFGroup -Name $saarGroupName -Description $saarDesc -Category "SAAR"
            $allGroups[$saarGroupName] = $group
        }
    }
}

# ═══════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════
Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  GROUP CREATION COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  HQ Admin Groups:        6 (5 role + 1 nested)" -ForegroundColor White
Write-Host "  Install G-6 Groups:     $($installG6Groups.Count + 1) ($($installG6Groups.Count) install + 1 nested)" -ForegroundColor White
Write-Host "  Directorate Groups:     $totalDirGroups" -ForegroundColor White
Write-Host "  SAAR Approver Groups:   $($allGroups.Keys | Where-Object { $_ -match 'SAARAprv' } | Measure-Object | Select-Object -ExpandProperty Count)" -ForegroundColor White
Write-Host "  ─────────────────────────────" -ForegroundColor Gray
Write-Host "  Total Groups Created:   $($allGroups.Count)" -ForegroundColor Cyan
Write-Host ""

# Export group inventory to CSV for reference
$groupExport = $allGroups.GetEnumerator() | ForEach-Object {
    [PSCustomObject]@{
        GroupName = $_.Key
        ObjectId  = if ($_.Value.Id) { $_.Value.Id } elseif ($_.Value.ObjectId) { $_.Value.ObjectId } else { "N/A" }
    }
}
$exportPath = Join-Path (Split-Path $ConfigPath) "azure-ad-groups-inventory.csv"
$groupExport | Export-Csv -Path $exportPath -NoTypeInformation
Write-Host "  Group inventory exported to: $exportPath" -ForegroundColor Gray
Write-Host ""
