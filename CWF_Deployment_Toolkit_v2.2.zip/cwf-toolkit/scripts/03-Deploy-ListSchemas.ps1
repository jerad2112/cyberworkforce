<#
.SYNOPSIS
    CWF Deployment Toolkit - Step 3: Deploy SharePoint List Schemas
.DESCRIPTION
    Deploys all CWF SharePoint lists with columns, views, indexing, and column formatting.
    Handles three site types differently:
    - MSC Hub: Reference lists, SyncErrorLog, Enforcement/Waiver lists, ComplianceStatus rollup
    - Installation Hub: ComplianceFlags, WaiverRequests, ComplianceStatus rollup, Enforcement/Waiver (read-only push)
    - Directorate: Transactional lists (Personnel, Certs, Training, SAAR, WorkRoles, Docs), ComplianceStatus
.NOTES
    Requires: PnP.PowerShell module
    Run AFTER: 02-Create-SharePointSites.ps1
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [ValidateSet("All", "MSCHub", "InstallHubs", "Directorates")]
    [string]$Target = "All",
    
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$tenantDomain = $config.MSC.TenantDomain
$sitePrefix = $config.SharePoint.SitePrefix
$hubUrl = $config.MSC.HubSiteUrl

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CWF TOOLKIT - List Schema Deployment" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Cyan

# ══════════════════════════════════════════════════════
# LIST DEFINITION FUNCTIONS
# ══════════════════════════════════════════════════════

function Deploy-CWFList {
    param(
        [string]$SiteUrl,
        [string]$ListName,
        [string]$ListDescription,
        [hashtable[]]$Columns,
        [hashtable[]]$Views,
        [string[]]$IndexColumns
    )
    
    Write-Host "    List: $ListName" -ForegroundColor White
    
    if ($WhatIf) {
        Write-Host "      [WhatIf] Would create list with $($Columns.Count) columns, $($Views.Count) views" -ForegroundColor DarkYellow
        return
    }
    
    # Connect to site
    Connect-PnPOnline -Url $SiteUrl -Interactive
    
    # Create list if it doesn't exist
    $existingList = Get-PnPList -Identity $ListName -ErrorAction SilentlyContinue
    if (-not $existingList) {
        New-PnPList -Title $ListName -Template GenericList -EnableContentTypes:$false
        Write-Host "      [CREATED] List" -ForegroundColor Green
    } else {
        Write-Host "      [EXISTS] List" -ForegroundColor DarkYellow
    }
    
    # Add columns
    foreach ($col in $Columns) {
        $existing = Get-PnPField -List $ListName -Identity $col.InternalName -ErrorAction SilentlyContinue
        if ($existing) {
            Write-Host "      [EXISTS] Column: $($col.InternalName)" -ForegroundColor DarkGray
            continue
        }
        
        $params = @{
            List         = $ListName
            DisplayName  = $col.DisplayName
            InternalName = $col.InternalName
            Type         = $col.Type
            Required     = if ($col.Required) { $true } else { $false }
        }
        
        # Handle Choice columns
        if ($col.Type -eq "Choice" -and $col.Choices) {
            $params.Choices = $col.Choices
        }
        
        # Handle Note (multiline) columns
        if ($col.Type -eq "Note") {
            $params.Add("AddToDefaultView", $false)
        }
        
        try {
            Add-PnPField @params
            
            # Set hidden if specified
            if ($col.Hidden -eq $true) {
                $field = Get-PnPField -List $ListName -Identity $col.InternalName
                Set-PnPField -List $ListName -Identity $col.InternalName -Values @{Hidden=$true}
            }
            
            Write-Host "      [ADDED] Column: $($col.InternalName)" -ForegroundColor Green
        } catch {
            Write-Host "      [ERROR] Column: $($col.InternalName) - $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    
    # Create indexed columns
    foreach ($indexCol in $IndexColumns) {
        try {
            $field = Get-PnPField -List $ListName -Identity $indexCol -ErrorAction SilentlyContinue
            if ($field) {
                Set-PnPField -List $ListName -Identity $indexCol -Values @{Indexed=$true}
                Write-Host "      [INDEXED] $indexCol" -ForegroundColor DarkCyan
            }
        } catch {
            Write-Host "      [WARN] Could not index: $indexCol" -ForegroundColor DarkYellow
        }
    }
    
    # Create views
    foreach ($view in $Views) {
        $existingView = Get-PnPView -List $ListName -Identity $view.Name -ErrorAction SilentlyContinue
        if ($existingView) {
            Write-Host "      [EXISTS] View: $($view.Name)" -ForegroundColor DarkGray
            continue
        }
        
        $viewParams = @{
            List   = $ListName
            Title  = $view.Name
            Fields = $view.Fields
        }
        
        if ($view.Query) {
            $viewParams.Query = $view.Query
        }
        if ($view.RowLimit) {
            $viewParams.RowLimit = $view.RowLimit
        }
        if ($view.SetAsDefault) {
            $viewParams.SetAsDefault = $true
        }
        
        try {
            Add-PnPView @viewParams
            Write-Host "      [ADDED] View: $($view.Name)" -ForegroundColor Green
        } catch {
            Write-Host "      [ERROR] View: $($view.Name) - $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

# ══════════════════════════════════════════════════════
# COMMON SYNC COLUMNS (present on all transactional lists)
# ══════════════════════════════════════════════════════

$syncColumns = @(
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
    @{ DisplayName="Sync Status"; InternalName="DV_SyncStatus"; Type="Choice"; Choices=@("Pending","Synced","Validation Error","Sync Failed") }
    @{ DisplayName="Last Sync"; InternalName="DV_LastSyncTimestamp"; Type="DateTime" }
    @{ DisplayName="Source Site URL"; InternalName="DV_SourceSiteURL"; Type="Text"; Hidden=$true }
    @{ DisplayName="Organization UIC"; InternalName="DV_OrgUIC"; Type="Text" }
    @{ DisplayName="Install G-6 Notes"; InternalName="G6Notes"; Type="Note" }
)

# ══════════════════════════════════════════════════════
# LIST DEFINITIONS
# ══════════════════════════════════════════════════════

# ── CWF_Personnel ──
$personnelColumns = @(
    @{ DisplayName="First Name"; InternalName="FirstName"; Type="Text"; Required=$true }
    @{ DisplayName="DoD ID"; InternalName="DoDID"; Type="Text"; Required=$true }
    @{ DisplayName="Email"; InternalName="PersonnelEmail"; Type="Text"; Required=$true }
    @{ DisplayName="Rank"; InternalName="Rank"; Type="Choice"; Choices=@("PVT","PFC","SPC","CPL","SGT","SSG","SFC","MSG","SGM","2LT","1LT","CPT","MAJ","LTC","COL","GS-05","GS-07","GS-09","GS-11","GS-12","GS-13","GS-14","GS-15") }
    @{ DisplayName="Duty Position"; InternalName="DutyPosition"; Type="Text" }
    @{ DisplayName="Office Symbol"; InternalName="OfficeSymbol"; Type="Text" }
    @{ DisplayName="Organization"; InternalName="OrgName"; Type="Text" }
    @{ DisplayName="Primary Work Role"; InternalName="PrimaryWorkRole"; Type="Text" }
) + $syncColumns

$personnelViews = @(
    @{ Name="My Records"; Fields=@("Title","FirstName","Rank","PersonnelEmail","PrimaryWorkRole","DV_SyncStatus"); Query="<Where><Eq><FieldRef Name='Author'/><Value Type='Integer'><UserID/></Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Personnel"; Fields=@("Title","FirstName","Rank","DoDID","PersonnelEmail","OrgName","PrimaryWorkRole","DV_SyncStatus"); RowLimit=100 }
    @{ Name="Pending Sync"; Fields=@("Title","FirstName","DV_SyncStatus","DV_LastSyncTimestamp"); Query="<Where><Neq><FieldRef Name='DV_SyncStatus'/><Value Type='Choice'>Synced</Value></Neq></Where>"; RowLimit=50 }
)

# ── CWF_MyCertifications ──
$certColumns = @(
    @{ DisplayName="Personnel Name"; InternalName="PersonnelName"; Type="Text"; Required=$true }
    @{ DisplayName="Certification"; InternalName="CertificationName"; Type="Choice"; Choices=@("CompTIA Security+","CompTIA CySA+","CompTIA CASP+","CISSP","CISM","CISA","CEH","CCNA","CCNP","PMP","CAP","GPEN","GCIA","GCIH","GSEC","SSCP","CCSP","Other") }
    @{ DisplayName="Provider"; InternalName="CertProvider"; Type="Choice"; Choices=@("CompTIA","ISC2","ISACA","EC-Council","Cisco","PMI","GIAC","Other") }
    @{ DisplayName="Issue Date"; InternalName="IssueDate"; Type="DateTime"; Required=$true }
    @{ DisplayName="Expiration Date"; InternalName="ExpirationDate"; Type="DateTime"; Required=$true }
    @{ DisplayName="Certificate Number"; InternalName="CertNumber"; Type="Text" }
    @{ DisplayName="Status"; InternalName="CertStatus"; Type="Choice"; Choices=@("Current","Expiring","Expired","Revoked") }
) + $syncColumns

$certViews = @(
    @{ Name="My Certifications"; Fields=@("Title","CertificationName","CertProvider","IssueDate","ExpirationDate","CertStatus","DV_SyncStatus"); Query="<Where><Eq><FieldRef Name='Author'/><Value Type='Integer'><UserID/></Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Certifications"; Fields=@("PersonnelName","CertificationName","CertProvider","IssueDate","ExpirationDate","CertStatus","DV_SyncStatus"); RowLimit=100 }
    @{ Name="Expiring (90 Days)"; Fields=@("PersonnelName","CertificationName","ExpirationDate","CertStatus"); Query="<Where><And><Leq><FieldRef Name='ExpirationDate'/><Value Type='DateTime'><Today OffsetDays='90'/></Value></Leq><Geq><FieldRef Name='ExpirationDate'/><Value Type='DateTime'><Today/></Value></Geq></And></Where>"; RowLimit=50 }
    @{ Name="Expired"; Fields=@("PersonnelName","CertificationName","ExpirationDate","CertStatus"); Query="<Where><Eq><FieldRef Name='CertStatus'/><Value Type='Choice'>Expired</Value></Eq></Where>"; RowLimit=50 }
)

# ── CWF_TrainingRecords ──
$trainingColumns = @(
    @{ DisplayName="Personnel Name"; InternalName="PersonnelName"; Type="Text"; Required=$true }
    @{ DisplayName="Course Name"; InternalName="CourseName"; Type="Text"; Required=$true }
    @{ DisplayName="Training Type"; InternalName="TrainingType"; Type="Choice"; Choices=@("Annual Mandatory","Work Role Specific","Continuous Education","On-the-Job Training","Leadership","Other"); Required=$true }
    @{ DisplayName="Completion Date"; InternalName="CompletionDate"; Type="DateTime"; Required=$true }
    @{ DisplayName="Hours"; InternalName="TrainingHours"; Type="Number" }
    @{ DisplayName="Provider"; InternalName="TrainingProvider"; Type="Text" }
    @{ DisplayName="Notes"; InternalName="TrainingNotes"; Type="Note" }
) + $syncColumns

$trainingViews = @(
    @{ Name="My Training"; Fields=@("CourseName","TrainingType","CompletionDate","TrainingHours","DV_SyncStatus"); Query="<Where><Eq><FieldRef Name='Author'/><Value Type='Integer'><UserID/></Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Training"; Fields=@("PersonnelName","CourseName","TrainingType","CompletionDate","TrainingHours","DV_SyncStatus"); RowLimit=100 }
    @{ Name="FY26 Training"; Fields=@("PersonnelName","CourseName","TrainingType","CompletionDate","TrainingHours"); Query="<Where><Geq><FieldRef Name='CompletionDate'/><Value Type='DateTime'>2025-10-01T00:00:00Z</Value></Geq></Where>"; RowLimit=100 }
)

# ── CWF_SAARRequests ──
$saarColumns = @(
    @{ DisplayName="Requestor Name"; InternalName="RequestorName"; Type="Text"; Required=$true }
    @{ DisplayName="System"; InternalName="SystemName"; Type="Choice"; Choices=@("ACAS/Tenable.sc","eMASS","ATCTS","HBSS/Trellix","Splunk SIEM","Army Vantage","Power Platform","Azure","SharePoint Admin","Other"); Required=$true }
    @{ DisplayName="Access Type"; InternalName="AccessType"; Type="Choice"; Choices=@("Standard User","Privileged User","Administrator","Read-Only"); Required=$true }
    @{ DisplayName="Justification"; InternalName="Justification"; Type="Note"; Required=$true }
    @{ DisplayName="Status"; InternalName="SAARStatus"; Type="Choice"; Choices=@("Draft","Submitted","Pending HQ Review","Approved","Returned","Denied","Expired") }
    @{ DisplayName="Supervisor Email"; InternalName="SupervisorEmail"; Type="Text" }
    @{ DisplayName="Submitted Date"; InternalName="SubmittedDate"; Type="DateTime" }
    @{ DisplayName="Decision Date"; InternalName="DecisionDate"; Type="DateTime" }
    @{ DisplayName="Decision By"; InternalName="DecisionBy"; Type="Text" }
    @{ DisplayName="Decision Notes"; InternalName="DecisionNotes"; Type="Note" }
) + $syncColumns

$saarViews = @(
    @{ Name="My SAAR Requests"; Fields=@("SystemName","AccessType","SAARStatus","SubmittedDate","DecisionDate","DV_SyncStatus"); Query="<Where><Eq><FieldRef Name='Author'/><Value Type='Integer'><UserID/></Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All SAAR Requests"; Fields=@("RequestorName","SystemName","AccessType","SAARStatus","SubmittedDate","DecisionBy","DV_SyncStatus"); RowLimit=100 }
    @{ Name="Pending Approval"; Fields=@("RequestorName","SystemName","AccessType","SubmittedDate","G6Notes"); Query="<Where><Eq><FieldRef Name='SAARStatus'/><Value Type='Choice'>Pending HQ Review</Value></Eq></Where>"; RowLimit=50 }
)

# ── CWF_MyWorkRoles ──
$workRoleColumns = @(
    @{ DisplayName="Personnel Name"; InternalName="PersonnelName"; Type="Text"; Required=$true }
    @{ DisplayName="DCWF Work Role"; InternalName="DCWFWorkRole"; Type="Text"; Required=$true }
    @{ DisplayName="DCWF ID"; InternalName="DCWFID"; Type="Text" }
    @{ DisplayName="Assignment Status"; InternalName="AssignmentStatus"; Type="Choice"; Choices=@("Requested","Approved","Active","Removed") }
    @{ DisplayName="Effective Date"; InternalName="EffectiveDate"; Type="DateTime" }
    @{ DisplayName="Is Primary"; InternalName="IsPrimary"; Type="Boolean" }
) + $syncColumns

$workRoleViews = @(
    @{ Name="My Work Roles"; Fields=@("DCWFWorkRole","DCWFID","AssignmentStatus","IsPrimary","DV_SyncStatus"); Query="<Where><Eq><FieldRef Name='Author'/><Value Type='Integer'><UserID/></Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Assignments"; Fields=@("PersonnelName","DCWFWorkRole","DCWFID","AssignmentStatus","IsPrimary","DV_SyncStatus"); RowLimit=100 }
)

# ── CWF_ComplianceStatus (Read-Only Push from DV) ──
$complianceColumns = @(
    @{ DisplayName="Personnel Name"; InternalName="PersonnelName"; Type="Text" }
    @{ DisplayName="Rank"; InternalName="Rank"; Type="Text" }
    @{ DisplayName="Organization"; InternalName="OrgName"; Type="Text" }
    @{ DisplayName="Work Role"; InternalName="PrimaryWorkRole"; Type="Text" }
    @{ DisplayName="Overall Score"; InternalName="OverallScore"; Type="Number" }
    @{ DisplayName="Cert Status"; InternalName="CertComplianceStatus"; Type="Choice"; Choices=@("Current","Expiring","Expired","N/A") }
    @{ DisplayName="Training Status"; InternalName="TrainingComplianceStatus"; Type="Choice"; Choices=@("Complete","Partial","Overdue","N/A") }
    @{ DisplayName="SAAR Status"; InternalName="SAARComplianceStatus"; Type="Choice"; Choices=@("Active","Pending","None","N/A") }
    @{ DisplayName="Active Waiver"; InternalName="HasActiveWaiver"; Type="Boolean" }
    @{ DisplayName="Enforcement Active"; InternalName="HasEnforcement"; Type="Boolean" }
    @{ DisplayName="Last Calculated"; InternalName="LastCalculated"; Type="DateTime" }
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
    @{ DisplayName="Organization UIC"; InternalName="DV_OrgUIC"; Type="Text" }
)

$complianceViews = @(
    @{ Name="My Compliance"; Fields=@("PersonnelName","OverallScore","CertComplianceStatus","TrainingComplianceStatus","SAARComplianceStatus","HasActiveWaiver","LastCalculated"); Query="<Where><Eq><FieldRef Name='Author'/><Value Type='Integer'><UserID/></Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="Org Compliance"; Fields=@("PersonnelName","Rank","PrimaryWorkRole","OverallScore","CertComplianceStatus","TrainingComplianceStatus","HasEnforcement","LastCalculated"); RowLimit=200 }
    @{ Name="Non-Compliant"; Fields=@("PersonnelName","Rank","OrgName","OverallScore","CertComplianceStatus","TrainingComplianceStatus","HasEnforcement"); Query="<Where><Lt><FieldRef Name='OverallScore'/><Value Type='Number'>70</Value></Lt></Where>"; RowLimit=100 }
)

# ── CWF_ComplianceFlags (Install Hub - G-6 submits to HQ) ──
$flagColumns = @(
    @{ DisplayName="Flag Type"; InternalName="FlagType"; Type="Choice"; Choices=@("Expired Cert","Overdue Training","SAAR Violation","Work Role Mismatch","Policy Violation","Other"); Required=$true }
    @{ DisplayName="Severity"; InternalName="Severity"; Type="Choice"; Choices=@("Low","Medium","High","Critical"); Required=$true }
    @{ DisplayName="Affected Personnel"; InternalName="AffectedPersonnel"; Type="Text" }
    @{ DisplayName="Affected Organization"; InternalName="AffectedOrg"; Type="Text" }
    @{ DisplayName="Description"; InternalName="FlagDescription"; Type="Note"; Required=$true }
    @{ DisplayName="Recommendation"; InternalName="Recommendation"; Type="Choice"; Choices=@("Monitor","Warning","Enforcement Action","Commander Notification","Waiver Recommended") }
    @{ DisplayName="Status"; InternalName="FlagStatus"; Type="Choice"; Choices=@("Submitted","Acknowledged by HQ","Under Review","Resolved - Action Taken","Resolved - No Action","Closed") }
    @{ DisplayName="HQ Response"; InternalName="HQResponse"; Type="Note" }
    @{ DisplayName="HQ Action Date"; InternalName="HQActionDate"; Type="DateTime" }
) + $syncColumns

$flagViews = @(
    @{ Name="Open Flags"; Fields=@("FlagType","Severity","AffectedPersonnel","AffectedOrg","FlagStatus","Created"); Query="<Where><And><Neq><FieldRef Name='FlagStatus'/><Value Type='Choice'>Closed</Value></Neq><Neq><FieldRef Name='FlagStatus'/><Value Type='Choice'>Resolved - No Action</Value></Neq></And></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Flags"; Fields=@("FlagType","Severity","AffectedPersonnel","FlagStatus","HQResponse","HQActionDate","DV_SyncStatus"); RowLimit=100 }
)

# ── CWF_WaiverRequests (Install Hub - G-6 requests from HQ) ──
$waiverReqColumns = @(
    @{ DisplayName="Waiver Type"; InternalName="WaiverType"; Type="Choice"; Choices=@("Certification Renewal","Training Deferral","SAAR Extension","Work Role Transition","Other"); Required=$true }
    @{ DisplayName="Affected Personnel"; InternalName="AffectedPersonnel"; Type="Text"; Required=$true }
    @{ DisplayName="Affected Organization"; InternalName="AffectedOrg"; Type="Text" }
    @{ DisplayName="Reason"; InternalName="WaiverReason"; Type="Note"; Required=$true }
    @{ DisplayName="Requested Duration (Days)"; InternalName="RequestedDays"; Type="Number" }
    @{ DisplayName="Status"; InternalName="WaiverReqStatus"; Type="Choice"; Choices=@("Draft","Submitted","Under HQ Review","Approved","Denied","Expired") }
    @{ DisplayName="HQ Decision"; InternalName="HQDecision"; Type="Note" }
    @{ DisplayName="Approved Duration (Days)"; InternalName="ApprovedDays"; Type="Number" }
    @{ DisplayName="Expiration Date"; InternalName="WaiverExpDate"; Type="DateTime" }
) + $syncColumns

$waiverReqViews = @(
    @{ Name="Open Requests"; Fields=@("WaiverType","AffectedPersonnel","WaiverReqStatus","Created","RequestedDays"); Query="<Where><Or><Eq><FieldRef Name='WaiverReqStatus'/><Value Type='Choice'>Submitted</Value></Eq><Eq><FieldRef Name='WaiverReqStatus'/><Value Type='Choice'>Under HQ Review</Value></Eq></Or></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Requests"; Fields=@("WaiverType","AffectedPersonnel","WaiverReqStatus","HQDecision","ApprovedDays","WaiverExpDate","DV_SyncStatus"); RowLimit=100 }
)

# ── CWF_EnforcementActions (Hub/Install Hub - HQ push, read-only at install) ──
$enforcementColumns = @(
    @{ DisplayName="Action Type"; InternalName="ActionType"; Type="Choice"; Choices=@("Warning","Access Suspension","Commander Notification","Privilege Revocation","Training Directive") }
    @{ DisplayName="Affected Personnel"; InternalName="AffectedPersonnel"; Type="Text" }
    @{ DisplayName="Affected Organization"; InternalName="AffectedOrg"; Type="Text" }
    @{ DisplayName="Description"; InternalName="ActionDescription"; Type="Note" }
    @{ DisplayName="Deadline"; InternalName="ActionDeadline"; Type="DateTime" }
    @{ DisplayName="Status"; InternalName="ActionStatus"; Type="Choice"; Choices=@("Active","Pending Resolution","Resolved","Escalated","Closed") }
    @{ DisplayName="Issued By"; InternalName="IssuedBy"; Type="Text" }
    @{ DisplayName="Issued Date"; InternalName="IssuedDate"; Type="DateTime" }
    @{ DisplayName="Resolution Notes"; InternalName="ResolutionNotes"; Type="Note" }
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
)

$enforcementViews = @(
    @{ Name="Active Enforcement"; Fields=@("ActionType","AffectedPersonnel","AffectedOrg","ActionDeadline","ActionStatus","IssuedBy"); Query="<Where><Or><Eq><FieldRef Name='ActionStatus'/><Value Type='Choice'>Active</Value></Eq><Eq><FieldRef Name='ActionStatus'/><Value Type='Choice'>Pending Resolution</Value></Eq></Or></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Actions"; Fields=@("ActionType","AffectedPersonnel","AffectedOrg","ActionStatus","IssuedDate","ActionDeadline"); RowLimit=100 }
)

# ── CWF_ComplianceWaivers (Hub/Install Hub - HQ push, read-only at install) ──
$waiverColumns = @(
    @{ DisplayName="Waiver Type"; InternalName="WaiverType"; Type="Choice"; Choices=@("Certification Renewal","Training Deferral","SAAR Extension","Work Role Transition","Other") }
    @{ DisplayName="Affected Personnel"; InternalName="AffectedPersonnel"; Type="Text" }
    @{ DisplayName="Reason"; InternalName="WaiverReason"; Type="Note" }
    @{ DisplayName="Granted By"; InternalName="GrantedBy"; Type="Text" }
    @{ DisplayName="Granted Date"; InternalName="GrantedDate"; Type="DateTime" }
    @{ DisplayName="Expiration Date"; InternalName="WaiverExpDate"; Type="DateTime" }
    @{ DisplayName="Status"; InternalName="WaiverStatus"; Type="Choice"; Choices=@("Active","Expiring","Expired","Revoked") }
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
)

$waiverViews = @(
    @{ Name="Active Waivers"; Fields=@("WaiverType","AffectedPersonnel","GrantedBy","GrantedDate","WaiverExpDate","WaiverStatus"); Query="<Where><Eq><FieldRef Name='WaiverStatus'/><Value Type='Choice'>Active</Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Waivers"; Fields=@("WaiverType","AffectedPersonnel","WaiverStatus","GrantedDate","WaiverExpDate"); RowLimit=100 }
)

# ── Reference Lists (Hub Only) ──
$workRoleCatalogColumns = @(
    @{ DisplayName="DCWF ID"; InternalName="DCWFID"; Type="Text" }
    @{ DisplayName="Work Role"; InternalName="WorkRoleName"; Type="Text" }
    @{ DisplayName="Category"; InternalName="DCWFCategory"; Type="Choice"; Choices=@("Securely Provision","Operate & Maintain","Oversee & Govern","Protect & Defend","Analyze","Collect & Operate","Investigate") }
    @{ DisplayName="Qualifying Certifications"; InternalName="QualifyingCerts"; Type="Note" }
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
)

$certCatalogColumns = @(
    @{ DisplayName="Certification"; InternalName="CertName"; Type="Text" }
    @{ DisplayName="Provider"; InternalName="CertProvider"; Type="Text" }
    @{ DisplayName="Renewal Period (Years)"; InternalName="RenewalYears"; Type="Number" }
    @{ DisplayName="DoD 8140 Approved"; InternalName="Is8140Approved"; Type="Boolean" }
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
)

$orgCatalogColumns = @(
    @{ DisplayName="UIC"; InternalName="OrgUIC"; Type="Text" }
    @{ DisplayName="Organization Name"; InternalName="OrgName"; Type="Text" }
    @{ DisplayName="Short Name"; InternalName="OrgShortName"; Type="Text" }
    @{ DisplayName="Hierarchy Level"; InternalName="HierarchyLevel"; Type="Choice"; Choices=@("L0","L1","L2","L3","L4","L5","L6") }
    @{ DisplayName="Parent UIC"; InternalName="ParentUIC"; Type="Text" }
    @{ DisplayName="Installation"; InternalName="InstallationName"; Type="Text" }
    @{ DisplayName="Is G-6"; InternalName="IsG6"; Type="Boolean" }
    @{ DisplayName="DV Record ID"; InternalName="DV_RecordID"; Type="Text"; Hidden=$true }
)

# ── SyncErrorLog (Hub Only) ──
$syncErrorColumns = @(
    @{ DisplayName="Flow ID"; InternalName="FlowID"; Type="Text" }
    @{ DisplayName="Flow Run URL"; InternalName="FlowRunURL"; Type="URL" }
    @{ DisplayName="Error Timestamp"; InternalName="ErrorTimestamp"; Type="DateTime" }
    @{ DisplayName="Source System"; InternalName="SourceSystem"; Type="Choice"; Choices=@("SharePoint","Dataverse","Power Automate") }
    @{ DisplayName="Source Record ID"; InternalName="SourceRecordID"; Type="Text" }
    @{ DisplayName="Error Type"; InternalName="ErrorType"; Type="Choice"; Choices=@("Validation","Sync","Lookup","Timeout","Throttle","Permission","Unknown") }
    @{ DisplayName="Error Message"; InternalName="ErrorMessage"; Type="Note" }
    @{ DisplayName="Source Site"; InternalName="SourceSiteURL"; Type="Text" }
    @{ DisplayName="Resolution"; InternalName="Resolution"; Type="Choice"; Choices=@("Pending","In Progress","Resolved","Ignored") }
    @{ DisplayName="Resolved By"; InternalName="ResolvedBy"; Type="Text" }
)

$syncErrorViews = @(
    @{ Name="Pending Errors"; Fields=@("FlowID","ErrorTimestamp","SourceSystem","ErrorType","ErrorMessage","SourceSiteURL"); Query="<Where><Eq><FieldRef Name='Resolution'/><Value Type='Choice'>Pending</Value></Eq></Where>"; SetAsDefault=$true; RowLimit=50 }
    @{ Name="All Errors"; Fields=@("FlowID","ErrorTimestamp","SourceSystem","ErrorType","Resolution","ResolvedBy"); RowLimit=200 }
)

# ══════════════════════════════════════════════════════
# DEPLOYMENT EXECUTION
# ══════════════════════════════════════════════════════

# ── MSC Hub ──
if ($Target -eq "All" -or $Target -eq "MSCHub") {
    Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│  Deploying to MSC Hub: $hubUrl" -ForegroundColor Cyan
    Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan
    
    Deploy-CWFList -SiteUrl $hubUrl -ListName "CWF_ComplianceStatus" -ListDescription "MSC-wide compliance rollup (read-only, pushed from DV)" -Columns $complianceColumns -Views $complianceViews -IndexColumns @("DV_OrgUIC","OverallScore")
    Deploy-CWFList -SiteUrl $hubUrl -ListName "CWF_EnforcementActions" -ListDescription "Enforcement actions issued by HQ" -Columns $enforcementColumns -Views $enforcementViews -IndexColumns @("ActionStatus")
    Deploy-CWFList -SiteUrl $hubUrl -ListName "CWF_ComplianceWaivers" -ListDescription "Active compliance waivers granted by HQ" -Columns $waiverColumns -Views $waiverViews -IndexColumns @("WaiverStatus","WaiverExpDate")
    Deploy-CWFList -SiteUrl $hubUrl -ListName "CWF_WorkRoles" -ListDescription "DCWF Work Role Catalog (reference data from DV)" -Columns $workRoleCatalogColumns -Views @(@{ Name="All Roles"; Fields=@("DCWFID","WorkRoleName","DCWFCategory","QualifyingCerts"); SetAsDefault=$true; RowLimit=200 }) -IndexColumns @("DCWFID")
    Deploy-CWFList -SiteUrl $hubUrl -ListName "CWF_Certifications" -ListDescription "Certification Catalog (reference data from DV)" -Columns $certCatalogColumns -Views @(@{ Name="All Certs"; Fields=@("CertName","CertProvider","RenewalYears","Is8140Approved"); SetAsDefault=$true; RowLimit=200 }) -IndexColumns @()
    Deploy-CWFList -SiteUrl $hubUrl -ListName "CWF_Organizations" -ListDescription "Organizational hierarchy (reference data from DV)" -Columns $orgCatalogColumns -Views @(@{ Name="Full Hierarchy"; Fields=@("OrgUIC","OrgName","HierarchyLevel","ParentUIC","InstallationName","IsG6"); SetAsDefault=$true; RowLimit=200 }) -IndexColumns @("OrgUIC","HierarchyLevel")
    Deploy-CWFList -SiteUrl $hubUrl -ListName "SyncErrorLog" -ListDescription "Power Automate sync error monitoring (HQ admin only)" -Columns $syncErrorColumns -Views $syncErrorViews -IndexColumns @("FlowID","Resolution","ErrorTimestamp")
}

# ── Installation Hubs ──
if ($Target -eq "All" -or $Target -eq "InstallHubs") {
    Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│  Deploying to Installation Hub Sites    │" -ForegroundColor Cyan
    Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan
    
    foreach ($install in $config.Installations) {
        $installUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)"
        Write-Host "`n  Installation: $($install.Name)" -ForegroundColor Yellow
        
        Deploy-CWFList -SiteUrl $installUrl -ListName "CWF_ComplianceStatus" -ListDescription "Installation compliance rollup" -Columns $complianceColumns -Views $complianceViews -IndexColumns @("DV_OrgUIC","OverallScore")
        Deploy-CWFList -SiteUrl $installUrl -ListName "CWF_ComplianceFlags" -ListDescription "G-6 compliance flags for HQ review" -Columns $flagColumns -Views $flagViews -IndexColumns @("FlagStatus","Severity","DV_SyncStatus")
        Deploy-CWFList -SiteUrl $installUrl -ListName "CWF_WaiverRequests" -ListDescription "Waiver requests submitted to HQ" -Columns $waiverReqColumns -Views $waiverReqViews -IndexColumns @("WaiverReqStatus","DV_SyncStatus")
        Deploy-CWFList -SiteUrl $installUrl -ListName "CWF_EnforcementActions" -ListDescription "Enforcement actions (read-only, pushed from HQ)" -Columns $enforcementColumns -Views $enforcementViews -IndexColumns @("ActionStatus")
        Deploy-CWFList -SiteUrl $installUrl -ListName "CWF_ComplianceWaivers" -ListDescription "Active waivers (read-only, pushed from HQ)" -Columns $waiverColumns -Views $waiverViews -IndexColumns @("WaiverStatus")
    }
}

# ── Directorate Sites ──
if ($Target -eq "All" -or $Target -eq "Directorates") {
    Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│  Deploying to Directorate Sites         │" -ForegroundColor Cyan
    Write-Host "└─────────────────────────────────────────┘`n" -ForegroundColor Cyan
    
    foreach ($install in $config.Installations) {
        foreach ($dir in $install.Directorates) {
            $dirUrl = "https://$tenantDomain/sites/$sitePrefix-$($install.Code)-$($dir.Code)"
            Write-Host "`n  Directorate: $($install.Code)-$($dir.Code) ($($dir.Name))" -ForegroundColor Yellow
            
            Deploy-CWFList -SiteUrl $dirUrl -ListName "CWF_Personnel" -ListDescription "CWF Personnel Records" -Columns $personnelColumns -Views $personnelViews -IndexColumns @("DV_OrgUIC","PersonnelEmail","DoDID","DV_SyncStatus")
            Deploy-CWFList -SiteUrl $dirUrl -ListName "CWF_MyCertifications" -ListDescription "Certification Records" -Columns $certColumns -Views $certViews -IndexColumns @("DV_OrgUIC","DV_SyncStatus","ExpirationDate")
            Deploy-CWFList -SiteUrl $dirUrl -ListName "CWF_TrainingRecords" -ListDescription "Training Completion Records" -Columns $trainingColumns -Views $trainingViews -IndexColumns @("DV_OrgUIC","DV_SyncStatus","CompletionDate")
            Deploy-CWFList -SiteUrl $dirUrl -ListName "CWF_SAARRequests" -ListDescription "System Access Authorization Requests" -Columns $saarColumns -Views $saarViews -IndexColumns @("DV_OrgUIC","SAARStatus","DV_SyncStatus")
            Deploy-CWFList -SiteUrl $dirUrl -ListName "CWF_MyWorkRoles" -ListDescription "Work Role Assignments" -Columns $workRoleColumns -Views $workRoleViews -IndexColumns @("DV_OrgUIC","DV_SyncStatus")
            Deploy-CWFList -SiteUrl $dirUrl -ListName "CWF_ComplianceStatus" -ListDescription "Compliance Status (read-only, pushed from DV)" -Columns $complianceColumns -Views $complianceViews -IndexColumns @("DV_OrgUIC","OverallScore")
            
            # Create document library
            Write-Host "    List: CWF_Documents" -ForegroundColor White
            if (-not $WhatIf) {
                Connect-PnPOnline -Url $dirUrl -Interactive
                $existingLib = Get-PnPList -Identity "CWF_Documents" -ErrorAction SilentlyContinue
                if (-not $existingLib) {
                    New-PnPList -Title "CWF_Documents" -Template DocumentLibrary
                    Write-Host "      [CREATED] Document Library" -ForegroundColor Green
                } else {
                    Write-Host "      [EXISTS] Document Library" -ForegroundColor DarkYellow
                }
            }
        }
    }
}

Write-Host "`n═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  LIST SCHEMA DEPLOYMENT COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════`n" -ForegroundColor Green
