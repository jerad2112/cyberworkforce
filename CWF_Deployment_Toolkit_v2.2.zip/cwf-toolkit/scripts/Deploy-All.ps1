<#
.SYNOPSIS
    CWF Deployment Toolkit - Master Orchestrator
.DESCRIPTION
    Runs all deployment steps in sequence:
    1. Create Azure AD security groups with nesting
    2. Create SharePoint sites (Hub + Installation + Directorate)
    3. Deploy list schemas (columns, views, indexing)
    4. Configure permissions (centralized HQ-Admin model)
    5. Write Site URLs back to Dataverse
.NOTES
    Run this script to execute the full deployment pipeline.
    Use -Step parameter to run individual steps.
    Use -WhatIf to preview changes without executing.
.EXAMPLE
    # Full deployment (preview mode)
    .\Deploy-All.ps1 -ConfigPath .\config\deployment-config.json -WhatIf
    
    # Full deployment (execute)
    .\Deploy-All.ps1 -ConfigPath .\config\deployment-config.json
    
    # Run only Step 3 (list schemas)
    .\Deploy-All.ps1 -ConfigPath .\config\deployment-config.json -Step 3
    
    # Run steps 2 through 4
    .\Deploy-All.ps1 -ConfigPath .\config\deployment-config.json -StartStep 2 -EndStep 4
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigPath,
    
    [int]$Step = 0,           # Run specific step only (1-5)
    [int]$StartStep = 1,      # Start from this step
    [int]$EndStep = 5,        # End at this step
    
    [string]$DataverseUrl,    # Required for Step 5
    
    [switch]$WhatIf,
    [switch]$UseGraphAPI      # Use Microsoft.Graph instead of AzureAD for Step 1
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Resolve config path
if (-not [System.IO.Path]::IsPathRooted($ConfigPath)) {
    $ConfigPath = Join-Path $scriptDir $ConfigPath
}

# Validate config exists
if (-not (Test-Path $ConfigPath)) {
    Write-Error "Configuration file not found: $ConfigPath"
    exit 1
}

$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json

Write-Host ""
Write-Host "╔═══════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                                                       ║" -ForegroundColor Cyan
Write-Host "║   CWF COMPLIANCE PORTAL - DEPLOYMENT TOOLKIT v2.2    ║" -ForegroundColor Cyan
Write-Host "║   Centralized HQ-Admin Model                         ║" -ForegroundColor Cyan
Write-Host "║                                                       ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "  MSC:             $($config.MSC.Name)" -ForegroundColor White
Write-Host "  Tenant:          $($config.MSC.TenantDomain)" -ForegroundColor White
Write-Host "  Installations:   $($config.Installations.Count)" -ForegroundColor White
$totalDirs = ($config.Installations | ForEach-Object { $_.Directorates.Count } | Measure-Object -Sum).Sum
Write-Host "  Directorates:    $totalDirs" -ForegroundColor White
Write-Host "  Config File:     $ConfigPath" -ForegroundColor Gray
if ($WhatIf) {
    Write-Host "  Mode:            PREVIEW (WhatIf)" -ForegroundColor Yellow
} else {
    Write-Host "  Mode:            EXECUTE" -ForegroundColor Red
}
Write-Host ""

# Determine which steps to run
if ($Step -gt 0) {
    $StartStep = $Step
    $EndStep = $Step
}

$steps = @(
    @{ Num=1; Name="Create Azure AD Security Groups"; Script="01-Create-AzureADGroups.ps1" }
    @{ Num=2; Name="Create SharePoint Sites"; Script="02-Create-SharePointSites.ps1" }
    @{ Num=3; Name="Deploy List Schemas"; Script="03-Deploy-ListSchemas.ps1" }
    @{ Num=4; Name="Configure Permissions"; Script="04-Configure-Permissions.ps1" }
    @{ Num=5; Name="Write Site URLs to Dataverse"; Script="05-Write-SiteURLs-ToDataverse.ps1" }
)

Write-Host "  Steps to execute: $StartStep through $EndStep" -ForegroundColor Yellow
Write-Host ""

# Confirmation
if (-not $WhatIf) {
    $confirm = Read-Host "  This will make changes to Azure AD, SharePoint, and Dataverse. Continue? (Y/N)"
    if ($confirm -ne "Y" -and $confirm -ne "y") {
        Write-Host "  Deployment cancelled." -ForegroundColor Red
        exit 0
    }
}

# Execute steps
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

foreach ($step in $steps) {
    if ($step.Num -lt $StartStep -or $step.Num -gt $EndStep) {
        continue
    }
    
    Write-Host ""
    Write-Host "╔═══════════════════════════════════════════════════════╗" -ForegroundColor Yellow
    Write-Host "║  STEP $($step.Num)/5: $($step.Name.PadRight(45))║" -ForegroundColor Yellow
    Write-Host "╚═══════════════════════════════════════════════════════╝" -ForegroundColor Yellow
    
    $scriptPath = Join-Path $scriptDir $step.Script
    
    if (-not (Test-Path $scriptPath)) {
        Write-Host "  [ERROR] Script not found: $scriptPath" -ForegroundColor Red
        continue
    }
    
    $stepStart = Get-Date
    
    $params = @{ ConfigPath = $ConfigPath }
    if ($WhatIf) { $params.WhatIf = $true }
    
    switch ($step.Num) {
        1 { if ($UseGraphAPI) { $params.UseGraphAPI = $true } }
        5 { 
            if (-not $DataverseUrl) {
                $DataverseUrl = $config.MSC.DataverseEnvironmentUrl
            }
            $params.DataverseUrl = $DataverseUrl
        }
    }
    
    try {
        & $scriptPath @params
        $stepDuration = (Get-Date) - $stepStart
        Write-Host "  Step $($step.Num) completed in $($stepDuration.ToString('mm\:ss'))" -ForegroundColor Green
    } catch {
        Write-Host "  [FATAL] Step $($step.Num) failed: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  Deployment halted. Fix the issue and re-run from Step $($step.Num):" -ForegroundColor Red
        Write-Host "  .\Deploy-All.ps1 -ConfigPath $ConfigPath -StartStep $($step.Num)" -ForegroundColor Yellow
        exit 1
    }
}

$stopwatch.Stop()

Write-Host ""
Write-Host "╔═══════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║                                                       ║" -ForegroundColor Green
Write-Host "║   DEPLOYMENT COMPLETE                                 ║" -ForegroundColor Green
Write-Host "║                                                       ║" -ForegroundColor Green
Write-Host "╚═══════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "  Total Duration:  $($stopwatch.Elapsed.ToString('hh\:mm\:ss'))" -ForegroundColor White
Write-Host "  MSC Hub:         $($config.MSC.HubSiteUrl)" -ForegroundColor Cyan
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor Yellow
Write-Host "  1. Import CWF Dataverse managed solution" -ForegroundColor White
Write-Host "  2. Load hierarchy CSV into cwf_Organization table" -ForegroundColor White
Write-Host "  3. Assign DV security roles to HQ staff" -ForegroundColor White
Write-Host "  4. Configure and activate Power Automate flows" -ForegroundColor White
Write-Host "  5. Create Canvas App Hub page with audience targeting" -ForegroundColor White
Write-Host "  6. Run UAT checklist from Build Guide Section 9" -ForegroundColor White
Write-Host ""
